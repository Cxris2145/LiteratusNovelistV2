"""Staff-only workbench; reader requests never enqueue billable generation."""
import copy
import uuid
from collections import Counter
from decimal import Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Count, Prefetch
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.exceptions import ValidationError as APIValidationError

from catalog.character_map_editorial import (EMPTY_PAYLOAD, approve_revision, project_revision,
    publish_revision, queue_book, save_draft, source_snapshot, validate_payload)
from catalog.models import (Book, Chapter, CharacterMapBudget, CharacterMapPublication, CharacterMapRevision)
from catalog.narration import chapter_words


def errors(exc):
    return Response({'errors': exc.messages if isinstance(exc, ValidationError) else [str(exc)]}, status=400)


def request_revision(book, revision_id):
    try:
        key = uuid.UUID(str(revision_id))
    except (ValueError, TypeError, AttributeError):
        raise APIValidationError({'errors': ['Selecciona una revisión válida.']})
    return get_object_or_404(CharacterMapRevision, book=book, pk=key)


def budget_data():
    budget = CharacterMapBudget.objects.filter(name='catalog').first()
    if not budget:
        return {'limit_usd': '100', 'spent_usd': '0', 'reserved_usd': '0', 'remaining_usd': '100',
                'model': 'gemini-2.5-flash', 'pricing_verified': False, 'pricing_source': '',
                'input_usd_per_million': '0.30', 'output_usd_per_million': '2.50'}
    return {'limit_usd': str(budget.limit_usd), 'spent_usd': str(budget.spent_usd),
        'reserved_usd': str(budget.reserved_usd),
        'remaining_usd': str(max(Decimal(0), budget.limit_usd - budget.spent_usd - budget.reserved_usd)),
        'model': budget.model, 'pricing_verified': bool(budget.pricing_verified_at and
            (timezone.now() - budget.pricing_verified_at).days < 30), 'pricing_source': budget.pricing_source,
        'input_usd_per_million': str(budget.input_usd_per_million),
        'output_usd_per_million': str(budget.output_usd_per_million)}


def check_stale(book, revision):
    if revision and revision.source_hash != source_snapshot(book)[0]:
        if revision.status != 'stale':
            CharacterMapRevision.objects.filter(pk=revision.pk).update(status='stale')
            revision.status = 'stale'
        return True
    return False


def revision_data(revision, include_payload=True):
    if not revision:
        return None
    result = {'id': str(revision.pk), 'status': revision.status, 'source_hash': revision.source_hash,
        'errors': revision.errors, 'reviewed_at': revision.reviewed_at, 'published_at': revision.published_at,
        'created_at': revision.created_at,
        'cost_usd': str(revision.cost_usd), 'input_tokens': revision.input_tokens,
        'output_tokens': revision.output_tokens, 'model': revision.model}
    if include_payload:
        result['payload'] = revision.payload
    return result


def detail(book, request):
    digest, chapters = source_snapshot(book)
    revision = book.character_map_revisions.first()
    check_stale(book, revision)
    publication = CharacterMapPublication.objects.filter(book=book).first()
    from ai_engine.models import AIAvatar
    avatars = AIAvatar.objects.filter(edition__book=book, is_author=False, is_active=True,
                                     edition__is_active=True, edition__deleted_at__isnull=True)
    return {'book': {'id': str(book.pk), 'title': book.title, 'slug': book.slug},
        'chapters': [{'id': str(c.pk), 'title': c.title, 'order': c.order, 'ordinal': ordinal,
                     'word_count': len(chapter_words(c.content_html)[0])}
                     for ordinal, c in enumerate(chapters) if c.is_active and not c.deleted_at],
        'avatars': [{'id': str(a.pk), 'name': a.name,
                     'portrait_url': request.build_absolute_uri(a.avatar_image.url) if a.avatar_image else None} for a in avatars],
        'revision': revision_data(revision),
        'published_revision_id': str(publication.revision_id) if publication else None,
        'source_hash': digest}


class MapListView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        books = Book.objects.filter(is_active=True, is_published=True).annotate(chapters_count=Count('chapters', distinct=True)).prefetch_related(
            Prefetch('character_map_revisions', queryset=CharacterMapRevision.objects.defer('payload').order_by('-created_at', '-id'), to_attr='map_revisions'),
            Prefetch('character_map_publication', queryset=CharacterMapPublication.objects.select_related('revision'))).order_by('word_count', 'title')
        rows = []
        coverage = Counter()
        published_count, no_characters_count = 0, 0
        for book in books:
            revision = book.map_revisions[0] if book.map_revisions else None
            publication = getattr(book, 'character_map_publication', None)
            state = revision.status if revision else 'pending'
            coverage[state] += 1
            if publication and publication.revision.status == 'published':
                published_count += 1
            if publication and publication.revision.status == 'no_characters':
                no_characters_count += 1
            if request.query_params.get('q') and request.query_params['q'].casefold() not in (book.title + ' ' + book.slug).casefold():
                continue
            if request.query_params.get('status') and state != request.query_params['status']:
                continue
            rows.append({'book_id': str(book.pk), 'title': book.title, 'slug': book.slug, 'status': state,
                'revision_id': str(revision.pk) if revision else None,
                'published_revision_id': str(publication.revision_id) if publication else None,
                'chapters_count': book.chapters_count, 'word_count': book.word_count,
                'error': '; '.join(str(e) for e in revision.errors) if revision else ''})
        try:
            page_size = max(1, min(100, int(request.query_params.get('page_size', 30))))
            page = max(1, int(request.query_params.get('page', 1)))
        except (ValueError, TypeError):
            return Response({'error': 'Página inválida.'}, status=400)
        return Response({'count': len(rows), 'page_size': page_size, 'page': page,
            'results': rows[(page - 1) * page_size:page * page_size], 'budget': budget_data(),
            'coverage': {'total': sum(coverage.values()), **{s: coverage[s] for s in (
                'pending', 'generating', 'review', 'approved', 'stale', 'failed', 'budget_paused')},
                'published': published_count, 'no_characters': no_characters_count}})


class MapDetailView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request, pk):
        return Response(detail(get_object_or_404(Book, pk=pk), request))

    def patch(self, request, pk):
        book = get_object_or_404(Book, pk=pk)
        payload = request.data.get('payload')
        if not isinstance(payload, dict):
            return Response({'errors': ['El mapa debe ser un objeto.']}, status=400)
        try:
            save_draft(book, request.data.get('revision_id'), payload, request.user)
            return Response(detail(book, request))
        except (ValidationError, ValueError) as exc:
            return errors(exc)


class MapGenerateView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request):
        books = Book.objects.filter(is_active=True, is_published=True).order_by('word_count', 'title')
        if request.data.get('all') is not True:
            ids = request.data.get('book_ids')
            if not isinstance(ids, list) or not ids:
                return Response({'errors': ['Selecciona libros o todo el catálogo.']}, status=400)
            try:
                books = books.filter(pk__in=ids)
            except (ValidationError, ValueError) as exc:
                return errors(exc)
        queued, failed = [], []
        for book in books:
            try:
                revision = queue_book(book, request.user, force=request.data.get('all') is not True)
                queued.append({'book_id': str(book.pk), 'revision_id': str(revision.pk), 'status': revision.status})
            except ValidationError as exc:
                failed.append({'book_id': str(book.pk), 'errors': exc.messages})
        return Response({'queued': queued, 'failed': failed, 'count': len(queued)}, status=202)


class MapActionView(APIView):
    permission_classes = [IsAdminUser]
    action = ''

    def post(self, request, pk):
        book = get_object_or_404(Book, pk=pk)
        revision = request_revision(book, request.data.get('revision_id'))
        try:
            if self.action == 'approve':
                approve_revision(revision, request.user, request.data.get('no_characters') is True, request.data.get('reason', ''))
            else:
                publish_revision(revision, request.user, restore=self.action == 'restore')
            return Response(detail(book, request))
        except (ValidationError, ValueError) as exc:
            return errors(exc)


class MapPreviewView(APIView):
    permission_classes = [IsAdminUser]

    def post(self, request, pk):
        book = get_object_or_404(Book, pk=pk)
        revision = request_revision(book, request.data.get('revision_id'))
        try:
            if revision.source_hash != source_snapshot(book)[0]:
                raise ValidationError('El texto ha cambiado; guarda el borrador para revalidar sus evidencias.')
            revision.payload = validate_payload(book, revision.payload)
            _, chapters = source_snapshot(book)
            chapter = int(request.data.get('chapter', -1))
            word = int(request.data.get('word', -1))
            if chapter < 0 or chapter >= len(chapters) or not chapters[chapter].is_active or chapters[chapter].deleted_at:
                raise ValidationError('Selecciona un capítulo activo (ordinal base 0).')
            if word < -1 or word >= len(chapter_words(chapters[chapter].content_html)[0]):
                raise ValidationError('La palabra no existe en este capítulo.')
            return Response(project_revision(revision, {'chapter': chapter, 'word': word}, request))
        except (ValidationError, ValueError, TypeError) as exc:
            return errors(exc)


class MapSourceView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request, pk):
        book = get_object_or_404(Book, pk=pk)
        try:
            chapter_id = uuid.UUID(str(request.query_params.get('chapter_id')))
        except (ValueError, TypeError, AttributeError):
            raise APIValidationError({'errors': ['Selecciona un capítulo válido.']})
        chapter = get_object_or_404(Chapter, book=book, pk=chapter_id, is_active=True)
        words, _ = chapter_words(chapter.content_html)
        return Response({'chapter_id': str(chapter.pk), 'title': chapter.title, 'text': ' '.join(words), 'words': words})


class MapHistoryView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request, pk):
        book = get_object_or_404(Book, pk=pk)
        return Response([revision_data(r, False) for r in book.character_map_revisions.all()])


class MapBudgetView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        return Response(budget_data())

    @transaction.atomic
    def patch(self, request):
        try:
            budget, _ = CharacterMapBudget.objects.get_or_create(name='catalog')
            budget = CharacterMapBudget.objects.select_for_update().get(pk=budget.pk)
            limit = Decimal(str(request.data.get('limit_usd', budget.limit_usd)))
            if not limit.is_finite() or not 0 <= limit <= 100 or limit < budget.spent_usd + budget.reserved_usd:
                raise ValidationError('El límite debe cubrir el gasto reservado y no superar US$100.')
            model = request.data.get('model', budget.model)
            input_rate = Decimal(str(request.data.get('input_usd_per_million', budget.input_usd_per_million)))
            output_rate = Decimal(str(request.data.get('output_usd_per_million', budget.output_usd_per_million)))
            source = request.data.get('pricing_source', budget.pricing_source)
            if model != 'gemini-2.5-flash' or input_rate != Decimal('.30') or output_rate != Decimal('2.50'):
                raise ValidationError('Este worker admite Gemini 2.5 Flash: US$0,30 entrada y US$2,50 salida por millón. Verifica nuevas tarifas antes de cambiar el proveedor.')
            if source not in ('https://ai.google.dev/gemini-api/docs/pricing', 'https://ai.google.dev/gemini-api/docs/pricing.md'):
                raise ValidationError('Usa la página oficial de tarifas de Gemini.')
            budget.limit_usd = limit
            budget.model = model
            budget.input_usd_per_million = input_rate
            budget.output_usd_per_million = output_rate
            budget.pricing_source = source
            if request.data.get('pricing_verified') is True:
                budget.pricing_verified_at = timezone.now()
            budget.save()
            return Response(budget_data())
        except (ValidationError, ValueError, InvalidOperation) as exc:
            return errors(exc)
