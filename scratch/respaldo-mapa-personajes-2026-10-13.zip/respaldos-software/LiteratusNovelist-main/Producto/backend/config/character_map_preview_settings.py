"""Local character-map preview: isolated SQLite and local portrait files."""
from .test_settings import *  # noqa: F403

# This preview always serves the fixture's SQLite, regardless of inherited test env vars.
DATABASES = {'default': {'ENGINE': 'django.db.backends.sqlite3',
                         'NAME': str(BASE_DIR / '.tmp-character-map-preview' / 'preview.sqlite3')}}

MEDIA_URL = '/media/'
CORS_ALLOWED_ORIGINS = ['http://localhost:4300', 'http://127.0.0.1:4300', 'http://localhost:4327', 'http://127.0.0.1:4327']
FRONTEND_URL = 'http://127.0.0.1:4300'
