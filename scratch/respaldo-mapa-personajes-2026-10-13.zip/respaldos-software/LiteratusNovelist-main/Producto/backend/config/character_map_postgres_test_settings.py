"""Run checks only in an explicitly named isolated PostgreSQL database."""
from .test_settings import *  # noqa: F403

database = DATABASES['default']  # noqa: F405
if database['ENGINE'] != 'django.db.backends.postgresql' or not database['NAME'].startswith('literatus_test_character_map_'):
    raise RuntimeError('La validación PostgreSQL requiere su base literatus_test_character_map_ aislada.')
database['TEST'] = {'NAME': database['NAME']}
database['CONN_MAX_AGE'] = 0
