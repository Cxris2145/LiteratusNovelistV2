"""Synthetic visual QA only. Never connects to, migrates or seeds the shared DB."""
import json
import os
import sys
from datetime import date
from pathlib import Path

backend = Path(__file__).resolve().parents[1]
preview_dir = backend / '.tmp-character-map-preview'
preview_dir.mkdir(exist_ok=True)
preview_db = preview_dir / 'preview.sqlite3'
sys.path.insert(0, str(backend))
os.environ['DJANGO_SETTINGS_MODULE'] = 'config.test_settings'
os.environ['LITERATUS_TEST_DB'] = str(preview_db)
os.environ.pop('LITERATUS_TEST_DATABASE_URL', None)

import django
django.setup()

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.management import call_command
from rest_framework_simplejwt.tokens import RefreshToken

if (settings.DATABASES['default']['ENGINE'] != 'django.db.backends.sqlite3'
        or Path(settings.DATABASES['default']['NAME']).resolve() != preview_db.resolve()):
    raise RuntimeError('La vista previa requiere exclusivamente su SQLite local aislada.')

call_command('migrate', verbosity=0)

from catalog.models import Author, Book, BookAuthor, BookCharacter, Chapter, CharacterFact, CharacterRelationship, Edition
from library.models import UserInventory

user, _ = get_user_model().objects.get_or_create(username='LectorMapa', defaults={'email': 'mapa@preview.example'})
profile = user.profile
profile.birth_date = date(1990, 1, 1)
profile.has_completed_onboarding = True
profile.ink_balance = 1000
profile.save()

book, _ = Book.objects.update_or_create(slug='el-jardin-de-las-cartas-preview', defaults={
    'title': 'El jardín de las cartas', 'synopsis': 'Relato ficticio creado para comprobar el mapa de personajes. Cinco vecinos restauran una biblioteca y descubren una correspondencia olvidada.',
    'is_published': True, 'status': 'published', 'min_age': 0,
})
author, _ = Author.objects.get_or_create(slug='equipo-de-pruebas', defaults={'full_name': 'Equipo de pruebas'})
BookAuthor.objects.get_or_create(book=book, author=author)
passages = [
    'Mara abre la biblioteca con Elio, su hermano. Nora ayuda a ordenar los estantes, mientras Ivo trae herramientas. Lía reúne a los vecinos para decidir qué reparar primero.',
    'Los cinco vecinos encuentran cartas sin destinatario. Comparan las fechas y reúnen las pistas que conocen. Elio pregunta quién guardaba la llave del armario.',
    'Ivo reconoce que ocultó una carta para proteger su proyecto. Mara le pide que explique lo ocurrido y el grupo decide escuchar su versión antes de actuar.',
]
chapters = []
for index, passage in enumerate(passages, start=1):
    html = f'<h1>Capítulo {index}</h1>' + ''.join(f'<p>{passage}</p>' for _ in range(12))
    chapter, _ = Chapter.objects.update_or_create(book=book, order=index, defaults={'title': f'Capítulo {index}', 'content_html': html})
    chapters.append(chapter)
book.recount_words()
edition, _ = Edition.objects.get_or_create(book=book, format='epub', defaults={'price': 0, 'language': 'es'})
inventory, _ = UserInventory.objects.get_or_create(user=user, edition=edition)

portraits = sorted((backend / 'media' / 'ai_avatars').glob('*.webp'))[:5]
if len(portraits) < 5:
    raise RuntimeError('La vista previa requiere cinco retratos locales existentes en media/ai_avatars.')
characters = []
for index, (name, role, description) in enumerate([
    ('Mara', 'protagonist', 'Organiza la restauración de la biblioteca del barrio.'),
    ('Elio', 'supporting', 'Ayuda a su hermana a recuperar los libros dañados.'),
    ('Nora', 'supporting', 'Colabora en la clasificación de la colección.'),
    ('Ivo', 'antagonist', 'Aporta herramientas para reparar los estantes.'),
    ('Lía', 'supporting', 'Coordina las reuniones de los vecinos.'),
]):
    character, _ = BookCharacter.objects.update_or_create(book=book, name=name, defaults={
        'portrait': portraits[index].relative_to(backend / 'media').as_posix(),
        'reveal_chapter': chapters[0], 'reveal_word': index * 8,
        'portrait_reveal_chapter': chapters[0], 'portrait_reveal_word': index * 8,
        'role': role, 'role_reveal_chapter': chapters[2] if name == 'Ivo' else chapters[0],
        'role_reveal_word': 40 if name == 'Ivo' else index * 8,
    })
    CharacterFact.objects.update_or_create(character=character, text=description,
                                          defaults={'reveal_chapter': chapters[0], 'reveal_word': 50})
    characters.append(character)
for source_index, target_index, kind, label in [
    (0, 1, 'family', 'Hermanos'), (0, 2, 'friend', 'Amigas'), (1, 3, 'ally', 'Colaboradores'),
    (2, 4, 'friend', 'Amigas'), (0, 4, 'ally', 'Vecinas'),
]:
    CharacterRelationship.objects.update_or_create(book=book, source=characters[source_index], target=characters[target_index], label=label,
                                                   defaults={'kind': kind, 'reveal_chapter': chapters[0], 'reveal_word': 60})
CharacterFact.objects.update_or_create(character=characters[3], text='Reconoce que ocultó una carta.',
                                      defaults={'reveal_chapter': chapters[2], 'reveal_word': 40})
CharacterRelationship.objects.update_or_create(book=book, source=characters[0], target=characters[3], label='En desacuerdo por la carta',
                                               defaults={'kind': 'enemy', 'reveal_chapter': chapters[2], 'reveal_word': 40})
progress = inventory.progress
progress.current_page = 1
progress.current_cfi = json.dumps({'wordId': 'word-90', 'percentage': 8, 'scrollPercent': 0.15})
progress.completion_percentage = 8
progress.save(update_fields=['current_page', 'current_cfi', 'completion_percentage'])

refresh = RefreshToken.for_user(user)
session = {'access': str(refresh.access_token), 'refresh': str(refresh),
           'user': {'id': str(user.pk), 'username': user.username, 'email': user.email,
                    'is_staff': False, 'is_superuser': False, 'has_completed_onboarding': True},
           'inventory_id': str(inventory.pk), 'progress_id': str(progress.pk), 'book_slug': book.slug,
           'book_id': str(book.pk)}
(preview_dir / 'session.json').write_text(json.dumps(session), encoding='utf-8')
print(f'Vista previa local creada: {preview_dir / "session.json"}')
print(f'Inventario: {inventory.pk}; libro: {book.slug}')
