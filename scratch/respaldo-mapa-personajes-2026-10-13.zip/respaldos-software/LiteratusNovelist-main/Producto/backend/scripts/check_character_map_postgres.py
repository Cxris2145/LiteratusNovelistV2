"""Create, test and remove only a uniquely named disposable PostgreSQL database."""
import os
import subprocess
import sys
import uuid
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

backend = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(backend))
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
import django
django.setup()
from django.conf import settings
from config.settings import env
import psycopg2
from psycopg2 import sql

name = 'literatus_test_character_map_' + uuid.uuid4().hex[:12]
assert name.startswith('literatus_test_character_map_') and name != settings.DATABASES['default']['NAME']
params = settings.DATABASES['default']
admin = psycopg2.connect(dbname=params['NAME'], user=params['USER'], password=params['PASSWORD'],
                         host=params['HOST'], port=params['PORT'], **params.get('OPTIONS', {}))
admin.autocommit = True
created = False
try:
    with admin.cursor() as cursor:
        cursor.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(name)))
    created = True
    url = urlsplit(env('DATABASE_URL'))
    test_env = dict(os.environ, DJANGO_SETTINGS_MODULE='config.character_map_postgres_test_settings',
                    LITERATUS_TEST_DATABASE_URL=urlunsplit(url._replace(path='/' + name)))
    temp = backend / '.tmp-character-map-tests'
    temp.mkdir(exist_ok=True)
    test_env.update(TMP=str(temp), TEMP=str(temp))
    print('Base aislada creada. Ejecutando migraciones y pruebas PostgreSQL.', flush=True)
    result = subprocess.run([sys.executable, 'manage.py', 'test', 'catalog.tests_character_map',
        'catalog.tests_character_map_editorial', 'catalog.tests_character_map_generation',
        '--settings=config.character_map_postgres_test_settings', '--keepdb', '--noinput'],
        cwd=backend, env=test_env, check=False)
    if result.returncode:
        raise SystemExit(result.returncode)
    print('Migraciones y pruebas PostgreSQL correctas.', flush=True)
finally:
    if created:
        # Cleanup is constrained to the exact database created by this invocation.
        assert name.startswith('literatus_test_character_map_') and name != params['NAME']
        with admin.cursor() as cursor:
            cursor.execute('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname=%s AND pid<>pg_backend_pid()', [name])
            cursor.execute(sql.SQL('DROP DATABASE {} WITH (FORCE)').format(sql.Identifier(name)))
        print('Base aislada de pruebas eliminada.', flush=True)
    admin.close()
