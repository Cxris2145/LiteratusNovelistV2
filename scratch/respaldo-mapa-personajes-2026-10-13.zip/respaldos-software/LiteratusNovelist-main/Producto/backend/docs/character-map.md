# Mapa de personajes sin spoilers

## Revisión de libros reales

En **Dashboard → Mapas de personajes** (`/dashboard/character-maps`) el administrador encuentra el catálogo, el presupuesto acumulado y sus borradores. Selecciona una obra para revisar personajes, vínculos, cambios de nombre/rol y uniones de identidades. Junto a cada dato puede abrir el texto fuente del capítulo y copiar un pasaje literal único. El backend calcula la última palabra de ese pasaje: los índices enviados por el navegador o la IA no son confiables ni se usan.

**Guardar borrador → revisar evidencias → Aprobar revisión → Publicar revisión** son acciones separadas. Los datos incompletos se guardan con errores para poder corregirlos, pero no se pueden aprobar. La ausencia de personajes exige una justificación. Editar una revisión publicada crea otro borrador; el mapa vigente sigue disponible. El historial permite recuperar una publicación anterior solo cuando coincide con el texto actual.

El extractor no publica automáticamente. Su cola, límites y comandos se describen en [Generación editorial](character-map-generation.md). Generar una propuesta o previsualizarla no modifica el progreso, la Tinta ni los datos privados de lectores.

Las evidencias, alias futuros y estados editoriales viven en revisiones privadas. Las publicaciones conservan los modelos de personajes/datos/relaciones asociados a la revisión y reconstruyen la presentación desde sus eventos conocidos. Los nombres por etapas y uniones solo se aplican después de sus evidencias. Una vigencia termina al alcanzar `until_evidence` (intervalo final exclusivo); un rol posterior vencido no hace reaparecer el anterior. La amistad/alianza y la enemistad de un mismo par requieren intervalos que no se superpongan.

La huella incluye texto, títulos, orden y disponibilidad de todos los capítulos; los ordinales coinciden exactamente con los capítulos no borrados del lector, incluidos los inactivos. El acceso público vuelve a comparar la huella para detectar también cambios realizados con actualizaciones masivas. Un mapa desactualizado no se sirve hasta revisar y publicar una versión compatible. Los retratos vinculados vuelven a comprobar libro, edición, autoría y disponibilidad en cada proyección.

### API editorial

Todas las rutas bajo `/api/v1/dashboard/character-maps/` exigen `IsAdminUser`:

- `GET /`: catálogo paginado (`q`, `status`, `page`, `page_size`), cobertura y presupuesto.
- `GET/PATCH /{book_id}/`: detalle y guardado de `{revision_id, payload}`; `revision_id: null` crea un borrador.
- `POST /generate/`: `{all: true}` o `{book_ids: [...]}`; encola sin llamadas de IA.
- `GET /{book_id}/source/?chapter_id=...`: texto tokenizado vigente para contrastar citas.
- `POST /{book_id}/preview/`: `{revision_id, chapter, word}`; posición editorial base 0, palabra `-1` para antes del capítulo.
- `POST /{book_id}/approve/`: `{revision_id, no_characters, reason}`.
- `POST /{book_id}/publish/`, `POST /{book_id}/restore/`: `{revision_id}`.
- `GET /{book_id}/history/`, `GET/PATCH /budget/`: historial y configuración verificada, con límite máximo US$100.

El payload contiene `characters`, `relationships`, `merges` y, opcionalmente, `no_characters_reason`. Cada personaje tiene `key`, `name`, `evidence`, `facts`, `names`, `roles` y un retrato opcional vinculado a un avatar del mismo libro con evidencia independiente. Cada hecho y relación tiene una clave estable y evidencia `{chapter_id, quote}`; los cambios pueden indicar `until_evidence`. Las relaciones apuntan a claves de esta revisión y las uniones indican `source`, `target` y su evidencia. Las claves y citas editoriales nunca se entregan al lector.

### Verificación de migraciones

`scripts/check_character_map_postgres.py` crea una base PostgreSQL temporal con nombre único `literatus_test_character_map_*`, ejecuta migraciones y pruebas, y elimina únicamente la base creada por esa invocación. Necesita permiso de creación de bases. Nunca ejecuta pruebas ni migraciones contra las tablas del catálogo compartido. Las pruebas rápidas usan `config.test_settings` y SQLite aislada.

```powershell
.\.venv\Scripts\python.exe manage.py test catalog.tests_character_map catalog.tests_character_map_editorial catalog.tests_character_map_generation --settings=config.test_settings
.\.venv\Scripts\python.exe scripts/check_character_map_postgres.py
```

El lector y la ficha del libro consultan `GET /api/v1/library/inventory/{id}/character-map/`. Solo el propietario autenticado puede consultar su inventario, respetando la edad mínima del libro. La respuesta usa su posición guardada en `ReadingProgress`; los parámetros de progreso enviados a este GET no tienen efecto.

`current_page` es el ordinal del capítulo (1..N), ordenado por `Chapter.order`, no el valor de `order`. `current_cfi` contiene JSON con `wordId: "word-N"`; N es el índice de palabra base 0 del lector, incluidos los títulos. `position.chapter` y `position.word` son base 0. Sin progreso válido, el capítulo es -1; una palabra ausente o inválida es -1 y no revela información del capítulo actual. No se deriva un índice de palabra de porcentajes ni del desplazamiento en píxeles. Al releer, el mapa refleja la posición actual guardada.

La respuesta contiene `characters`, `relationships`, `position` y `available`. Cada personaje visible contiene `id`, `name`, `portrait_url` (o null), `role` (o null) y `facts: [{id, text}]`. Cada relación contiene `id`, `source_id`, `target_id`, `kind` y `label`. No se devuelven identidades futuras, conteos bloqueados, fechas de revelación ni perfiles de IA. `available` indica únicamente si el libro cuenta con datos curatoriales activos. La respuesta lleva `Cache-Control: private, no-store`; el frontend envía `ngsw-bypass` para evitar respuestas antiguas del service worker.

## Preparación editorial

La migración `catalog/0029_bookcharacter_characterfact_characterrelationship.py` agrega las tablas. El despliegue debe aplicar las migraciones a su base de destino antes de activar esta interfaz. No se incluyen datos de obras reales: cada mapa necesita una revisión editorial de la edición y de sus capítulos.

1. En el admin de Django, crea **Personajes del mapa**. Selecciona el libro, el nombre que el lector conoce en ese momento y la primera palabra que permite revelar esa identidad. No uses el nombre real temprano si este es un giro de la historia.
2. Carga un retrato o vincula un avatar del mismo libro. Su capítulo y palabra de revelación son independientes. Una imagen también puede revelar identidad, vestimenta o acontecimientos; revísala antes de elegir ese punto. Sin capítulo de retrato no se envía imagen. El avatar aporta únicamente su imagen; su descripción, instrucciones, nombre y clasificación nunca se copian al mapa. Cuando `MEDIA_URL` apunta al almacenamiento público de Supabase, el admin copia cada retrato nuevo con `core.storage.upload_to_supabase_if_configured`; una copia fallida muestra una advertencia para repetir la carga. Los scripts de importación deben sincronizar sus archivos con ese helper o vincular imágenes ya subidas.
3. Define el rol cuando corresponde: protagonista, antagonista o secundario. Su capítulo y palabra de revelación son obligatorios para un rol no vacío. La identidad de un antagonista puede conocerse mucho después de su primera aparición.
4. Agrega **Datos de personajes** como fragmentos breves, cada uno con su punto de revelación. Evita una biografía que reúna información futura. Agrega **Relaciones del mapa** con una etiqueta precisa y segura en ese punto; solo aparecen cuando ambos personajes y la relación ya se conocen.

Para encontrar los índices exactos, usa `catalog.narration.chapter_words(chapter.content_html)` en una consola Django editorial y enumera el primer elemento del resultado. Usa la misma función para scripts de importación; `BookCharacter.objects.create()`, `CharacterFact.objects.create()` y `CharacterRelationship.objects.create()` validan al guardar que los capítulos, avatares y personajes pertenezcan al mismo libro y que las palabras existan. Usa `transaction.atomic()` en una importación completa. `bulk_create()` y `QuerySet.update()` evitan la validación del modelo y no se recomiendan para cargar mapas.

No modifiques la numeración ni el contenido de un capítulo después de curar su mapa sin revisar sus puntos de revelación. Las posiciones están vinculadas al texto y tokenización de esa versión. El modelo impide borrar físicamente un capítulo usado como punto de revelación; las entidades desactivadas o borradas lógicamente no se proyectan.

## Pruebas y vista previa local

Desde `Producto/backend`:

```powershell
.\.venv\Scripts\python.exe manage.py test catalog.tests_character_map --settings=config.test_settings
.\.venv\Scripts\python.exe scripts\preview_character_map.py
$env:LITERATUS_TEST_DB = (Join-Path (Get-Location) '.tmp-character-map-preview\preview.sqlite3')
.\.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8010 --settings=config.character_map_preview_settings --noreload
```

La vista previa migra únicamente `.tmp-character-map-preview/preview.sqlite3`, agrega un relato ficticio y reutiliza cinco archivos locales de retratos para comprobar la presentación. No realiza peticiones de IA ni copia hechos de una obra real. `.tmp-character-map-preview/session.json` contiene la sesión local, el inventario y los identificadores de progreso/libro; no publiques este archivo. El servidor de vista previa sirve los retratos locales y permite el frontend `http://127.0.0.1:4300`.

La posición inicial es capítulo 1, `word-90`: cinco personajes, cinco relaciones y el rol de Ivo todavía desconocido. Para comparar estados, actualiza el progreso de esta cuenta local a capítulo 1/`word-0` (solo primera identidad), capítulo 1/`word-60` (cinco personajes y relaciones), o capítulo 3/`word-40` (rol y relación posteriores). La muestra es solo una fixture de QA; no forma parte del catálogo de producción.

Desde `Producto/frontend`, las pruebas del mapa se ejecutan con un `tsconfig` dedicado para evitar los errores de tipos existentes en pruebas de otras funcionalidades:

```powershell
$env:CHROME_BIN = 'C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe'
npm.cmd test -- --watch=false --browsers=ChromeHeadless --ts-config=tsconfig.character-map.spec.json --include=src/app/library/reader/character-map/*.spec.ts --include=src/app/library/reader/reader-progress.util.spec.ts --include=src/app/core/utils/chapter-parser.util.spec.ts
node scripts/audit-character-map.mjs --start-servers
```

La auditoría renueva la fixture, inicia servidores propios en los puertos 4327/8027, redirige el API del build de vista previa a esa SQLite y termina los procesos que creó. Comprueba diagrama/lista, móvil, desbloqueos posteriores, relectura y cierre del diálogo desde el lector; guarda capturas y un informe en `frontend/docs/audits/character-map/`. No genera imágenes, voces ni contenido mediante IA.
