# Generación editorial de mapas

La cola guarda una revisión privada por obra y una posición por fragmento. El worker es un comando Django independiente del servidor web. No publica, no genera retratos y no usa Tinta. `Chapter.content_html`, leído mediante `chapter_words()`, es la única fuente de propuestas.

## Preparación y comprobación

Aplica las migraciones primero en una base aislada. Para pruebas usa `--settings=config.test_settings`; esa configuración nunca usa la conexión compartida. El worker normal usa las credenciales Gemini y la base configuradas para Django.

```powershell
.\.venv\Scripts\python.exe manage.py test catalog.tests_character_map_generation --settings=config.test_settings
.\.venv\Scripts\python.exe manage.py queue_character_maps --pilots --dry-run
.\.venv\Scripts\python.exe manage.py character_map_worker --dry-run
```

Encola primero **La metamorfosis**, **Alicia en el País de las Maravillas** y **Orgullo y prejuicio**. El comando admite `--book UUID` repetido para una selección exacta. `--all` recorre obras activas publicadas, prioriza pilotos y luego longitud creciente; informa las obras sin texto activo.

```powershell
.\.venv\Scripts\python.exe manage.py queue_character_maps --pilots
.\.venv\Scripts\python.exe manage.py character_map_worker --verify-pricing --max-jobs 3
```

`--verify-pricing` registra la tarifa incluida en esta versión, comprobada el **13 de octubre de 2026** en [Google AI](https://ai.google.dev/gemini-api/docs/pricing): Gemini 2.5 Flash Standard, US$0,30 por millón de tokens de entrada de texto y US$2,50 por millón de salida. La verificación caduca después de 30 días y no puede renovarse cambiando solo el reloj: una nueva verificación requiere actualizar la tarifa y la fecha tras revisar la fuente oficial. No hay modelos alternativos, búsqueda, herramientas, caché de pago ni audio; el pensamiento está desactivado y cada respuesta tiene un máximo de 4.096 tokens.

## Revisión y continuación

Cuando termina una obra, su estado es **En revisión**, incluso cuando no se encontraron personajes. Un administrador debe comprobar las evidencias y aprobar/publicar explícitamente en **Dashboard → Mapas de personajes**. Un mapa vacío requiere una justificación editorial; un fallo de generación no certifica que la obra carezca de personajes.

Una vez validados los pilotos, encola el resto y ejecuta el worker:

```powershell
.\.venv\Scripts\python.exe manage.py queue_character_maps --all
.\.venv\Scripts\python.exe manage.py character_map_worker --max-jobs 0
```

`--max-jobs 0` procesa como máximo los trabajos en la cola inicial y se detiene al agotar esa lista. `--max-fragments N` devuelve cada obra a pendiente después de N fragmentos correctos, conservando el cursor. Al reiniciar, los fragmentos confirmados no vuelven a generarse. El worker no corre permanentemente; puede ejecutarse nuevamente desde un supervisor o tarea operativa del servidor.

Los trabajos pausados necesitan corregir la configuración o disponer de presupuesto antes de reanudarlos. Los fallidos requieren revisar su error y una reanudación explícita:

```powershell
.\.venv\Scripts\python.exe manage.py character_map_worker --resume --max-jobs 0
.\.venv\Scripts\python.exe manage.py character_map_worker --retry-failed --max-jobs 1
```

## Presupuesto y recuperación

El presupuesto global de esta función tiene un límite acumulado máximo de **US$100**, incluidos reintentos. Antes de cada llamada el worker bloquea el presupuesto y registra una reserva con el máximo de entrada previsto, el esquema y 4.096 tokens de salida. El máximo de entrada usa el conteo de Gemini y un límite conservador basado en bytes UTF-8; los tokens reales devueltos por Gemini liberan el exceso reservado.

Una llamada con respuesta o facturación desconocida consume su reserva completa. Los errores del proveedor y las respuestas inválidas cuentan como intentos pagados; el SDK no hace reintentos ocultos. Tras tres fallos de un fragmento se requiere intervención editorial. Los costes y el registro de llamadas permanecen al reanudar.

Cada trabajo tiene un arrendamiento de diez minutos; el tiempo máximo de una llamada es tres minutos. Otro worker puede recuperar un arrendamiento vencido. Una reserva abandonada se carga conservadoramente antes de repetir el fragmento. No borres el registro de llamadas ni reduzcas importes reservados para desbloquear trabajos: una respuesta perdida puede haber sido cobrada por el proveedor.

Si cambia el texto, el orden o la disponibilidad de capítulos, la huella deja de coincidir y el trabajo se marca desactualizado. La cola nunca corrige automáticamente anclajes ni publica una revisión incompatible.

## Modo automático (`--auto`)

Para completar el catálogo sin revisar cada obra a mano (decisión del 2026-10-13), el worker tiene un modo automático:

```powershell
.\.venv\Scripts\python.exe manage.py queue_character_maps --all
.\.venv\Scripts\python.exe manage.py character_map_worker --auto --max-jobs 0
```

Diferencias con el modo editorial (que sigue igual y es el predeterminado):

- **Citas tolerantes.** La cita se busca en el fragmento sin distinguir signos, comillas, rayas, mayúsculas ni tildes, y se reescribe con el texto exacto del libro. Si se repite en el capítulo, se amplía hacia atrás hasta que sea única. Nunca se acepta texto que no esté en lo ya leído.
- **Descarte selectivo.** Se descarta solo la propuesta inválida, no el fragmento completo. Si la fusión aún no valida, se conservan únicamente las identidades nuevas; si tampoco, el fragmento no aporta datos.
- **Contexto compacto.** La ficha previa viaja sin citas ni anclajes, solo con claves, nombres, roles, hechos y vínculos, y se piden citas de 8 a 25 palabras. Esto abarata mucho las obras largas.
- **Fragmentos que fallan.** Tras tres fallos, el fragmento se salta (queda en `checkpoints.skipped`) en vez de detener la obra.
- **Límite de Gemini (429).** No se cobra ni cuenta como intento. Tras 12 seguidos, la obra se pausa.
- **Publicación.** Al terminar, el mapa se aprueba y publica si valida por completo. Un mapa sin personajes queda en revisión: certificar su ausencia sigue siendo editorial.

Se pueden correr varios workers a la vez; cada obra se reserva con su arrendamiento. El tope acumulado de US$100 aplica igual.
