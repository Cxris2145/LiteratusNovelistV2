import copy
import json
from datetime import date
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import RequestFactory
from rest_framework.test import APITestCase

from catalog.character_map_editorial import (approve_revision, evidence_anchor, project_revision,
    publish_revision, queue_book, save_draft, source_snapshot, validate_payload)
from catalog.models import (Book, BookCharacter, Chapter, CharacterMapJob, CharacterMapPublication,
                            CharacterMapRevision, Edition)
from library.models import UserInventory


class EditorialMapTests(APITestCase):
    def setUp(self):
        self.staff = get_user_model().objects.create_user('map-editor', email='editor@test.example', password='test', is_staff=True)
        self.reader = get_user_model().objects.create_user('map-owner', email='owner@test.example', password='test')
        self.reader.profile.birth_date = date(1990, 1, 1)
        self.reader.profile.save()
        self.book = Book.objects.create(title='Relato editorial de prueba', is_published=True, status='published')
        self.first = Chapter.objects.create(book=self.book, order=4, title='Inicio', content_html=
            '<h1>Inicio</h1><p>Mara llega al jardín. Elio saluda a Mara. Los dos son amigos.</p>')
        self.last = Chapter.objects.create(book=self.book, order=20, title='Después', content_html=
            '<p>Elio rompe su alianza con Mara. El visitante se presenta como Elio. Ahora Elio se opone a Mara.</p>')
        self.edition = Edition.objects.create(book=self.book, price=0)
        self.inventory = UserInventory.objects.create(user=self.reader, edition=self.edition)
        self.payload = {'characters': [
            {'key': 'mara', 'name': 'Mara', 'evidence': self.ev(self.first, 'Mara llega al jardín.'),
             'facts': [{'key': 'garden', 'text': 'Llega al jardín.', 'evidence': self.ev(self.first, 'Mara llega al jardín.')}]},
            {'key': 'elio', 'name': 'Elio', 'evidence': self.ev(self.first, 'Elio saluda a Mara.'), 'facts': []}],
            'relationships': [{'key': 'friends', 'source': 'mara', 'target': 'elio', 'kind': 'friend', 'label': 'Amigos',
                'evidence': self.ev(self.first, 'Los dos son amigos.'),
                'until_evidence': self.ev(self.last, 'Elio rompe su alianza con Mara.')},
                {'key': 'enemies', 'source': 'mara', 'target': 'elio', 'kind': 'enemy', 'label': 'En desacuerdo',
                 'evidence': self.ev(self.last, 'Ahora Elio se opone a Mara.')}], 'merges': []}
        self.request = RequestFactory().get('/', HTTP_HOST='testserver')
        self.base = '/api/v1/dashboard/character-maps/'

    def ev(self, chapter, quote):
        return {'chapter_id': str(chapter.pk), 'quote': quote}

    def draft(self, payload=None):
        return save_draft(self.book, None, payload or self.payload, self.staff)

    def publish(self, payload=None):
        revision = self.draft(payload)
        approve_revision(revision, self.staff)
        revision.refresh_from_db()
        return publish_revision(revision, self.staff)

    def reader_map(self, chapter, word):
        progress = self.inventory.progress
        progress.current_page = chapter + 1
        progress.current_cfi = json.dumps({'wordId': f'word-{word}'})
        progress.save()
        self.client.force_authenticate(self.reader)
        response = self.client.get(f'/api/v1/library/inventory/{self.inventory.pk}/character-map/')
        self.assertEqual(response.status_code, 200)
        return response.data

    def test_offsets_are_calculated_not_trusted(self):
        raw = copy.deepcopy(self.payload)
        raw['characters'][0]['evidence'].update(start_word=0, end_word=0, chapter=100)
        evidence = validate_payload(self.book, raw)['characters'][0]['evidence']
        self.assertEqual(evidence['chapter'], 0)
        self.assertEqual(evidence['start_word'], 1)
        self.assertEqual(evidence['end_word'], 4)

    def test_repeated_wrong_and_other_book_quotes_are_rejected(self):
        other = Book.objects.create(title='Otro libro')
        chapter = Chapter.objects.create(book=other, order=1, content_html='<p>Mara llega al jardín.</p>')
        for evidence in (self.ev(self.last, 'Elio'), self.ev(self.first, 'Pasaje inexistente.'), self.ev(chapter, 'Mara llega al jardín.')):
            with self.subTest(evidence=evidence), self.assertRaises(ValidationError):
                evidence_anchor(evidence, source_snapshot(self.book)[1])

    def test_draft_invalid_evidence_is_saved_but_cannot_be_approved(self):
        payload = copy.deepcopy(self.payload)
        payload['characters'][0]['evidence']['quote'] = 'No aparece.'
        revision = self.draft(payload)
        self.assertTrue(revision.errors)
        with self.assertRaises(ValidationError):
            approve_revision(revision, self.staff)
        self.assertFalse(self.reader_map(1, 17)['available'])

    def test_publication_requires_review_and_materializes_existing_models(self):
        revision = self.draft()
        with self.assertRaises(ValidationError):
            publish_revision(revision, self.staff)
        approve_revision(revision, self.staff)
        revision.refresh_from_db()
        publish_revision(revision, self.staff)
        self.assertEqual(BookCharacter.objects.filter(revision=revision).count(), 2)
        self.assertEqual(CharacterMapPublication.objects.get(book=self.book).revision_id, revision.pk)

    def test_exact_boundary_private_evidence_and_rereading(self):
        self.publish()
        self.assertEqual(self.reader_map(0, 3)['characters'], [])
        early = self.reader_map(0, 4)
        self.assertEqual([c['name'] for c in early['characters']], ['Mara'])
        self.assertEqual(early['relationships'], [])
        known = self.reader_map(0, 12)
        self.assertEqual([r['kind'] for r in known['relationships']], ['friend'])
        late = self.reader_map(1, 17)
        self.assertEqual([r['kind'] for r in late['relationships']], ['enemy'])
        self.assertNotIn('evidence', json.dumps(late))
        self.assertNotIn('quote', json.dumps(late))
        self.assertNotIn('source_hash', json.dumps(late))
        self.assertEqual([r['kind'] for r in self.reader_map(0, 12)['relationships']], ['friend'])

    def test_alias_merge_does_not_reveal_connection_until_its_evidence(self):
        payload = copy.deepcopy(self.payload)
        payload['characters'].append({'key': 'visitor', 'name': 'El visitante',
            'evidence': self.ev(self.last, 'El visitante'), 'facts': [],
            'names': [{'name': 'Elio', 'evidence': self.ev(self.last, 'El visitante se presenta como Elio.')}]})
        payload['merges'] = [{'source': 'visitor', 'target': 'elio',
            'evidence': self.ev(self.last, 'El visitante se presenta como Elio.')}]
        revision = self.publish(payload)
        before = project_revision(revision, {'chapter': 1, 'word': 8}, self.request)
        self.assertEqual(len(before['characters']), 3)
        self.assertIn('El visitante', [c['name'] for c in before['characters']])
        after = project_revision(revision, {'chapter': 1, 'word': 12}, self.request)
        self.assertEqual(len(after['characters']), 2)
        again = project_revision(revision, {'chapter': 1, 'word': 8}, self.request)
        self.assertEqual(before, again)

    def test_changing_roles_follow_position(self):
        payload = copy.deepcopy(self.payload)
        payload['characters'][1].update(role='supporting', role_evidence=self.ev(self.first, 'Elio saluda a Mara.'),
            roles=[{'role': 'antagonist', 'evidence': self.ev(self.last, 'Ahora Elio se opone a Mara.')}])
        revision = self.publish(payload)
        self.assertEqual(project_revision(revision, {'chapter': 0, 'word': 13}, self.request)['characters'][1]['role'], 'supporting')
        self.assertEqual(project_revision(revision, {'chapter': 1, 'word': 20}, self.request)['characters'][1]['role'], 'antagonist')

    def test_expired_latest_role_does_not_resurrect_previous_role(self):
        payload = copy.deepcopy(self.payload)
        payload['characters'][1].update(role='supporting', role_evidence=self.ev(self.first, 'Elio saluda a Mara.'),
            roles=[{'role': 'antagonist', 'evidence': self.ev(self.last, 'Elio rompe su alianza con Mara.'),
                    'until_evidence': self.ev(self.last, 'Ahora Elio se opone a Mara.')}])
        revision = self.publish(payload)
        self.assertIsNone(project_revision(revision, {'chapter': 1, 'word': 17}, self.request)['characters'][1]['role'])

    def test_soft_deleted_chapters_do_not_shift_reader_ordinals(self):
        self.first.delete()
        evidence = evidence_anchor(self.ev(self.last, 'Elio rompe su alianza con Mara.'), source_snapshot(self.book)[1])
        self.assertEqual(evidence['chapter'], 0)

    def test_inactive_chapter_has_consistent_editorial_ordinal(self):
        self.first.is_active = False
        self.first.save()
        self.client.force_authenticate(self.staff)
        response = self.client.get(self.base + f'{self.book.pk}/')
        self.assertEqual(response.data['chapters'][0]['ordinal'], 1)

    def test_invalid_revision_identifier_returns_validation_error(self):
        self.client.force_authenticate(self.staff)
        for action in ('preview', 'approve', 'publish', 'restore'):
            response = self.client.post(self.base + f'{self.book.pk}/{action}/', {'revision_id': 'malformed'}, format='json')
            self.assertEqual(response.status_code, 400)

    def test_contradictory_relationship_intervals_require_correction(self):
        payload = copy.deepcopy(self.payload)
        del payload['relationships'][0]['until_evidence']
        with self.assertRaises(ValidationError):
            validate_payload(self.book, payload)

    def test_save_published_map_creates_separate_draft_and_restore_is_atomic(self):
        revision = self.publish()
        before = self.reader_map(0, 12)
        payload = copy.deepcopy(self.payload)
        payload['characters'][0]['name'] = 'Mara corregida'
        draft = save_draft(self.book, revision.pk, payload, self.staff)
        self.assertNotEqual(draft.pk, revision.pk)
        self.assertEqual(self.reader_map(0, 12), before)
        approve_revision(draft, self.staff)
        draft.refresh_from_db()
        publish_revision(draft, self.staff)
        self.assertEqual(self.reader_map(0, 12)['characters'][0]['name'], 'Mara corregida')
        publish_revision(revision, self.staff, restore=True)
        self.assertEqual(self.reader_map(0, 12), before)

    def test_source_hash_catches_bulk_changes_even_without_signals(self):
        revision = self.publish()
        Chapter.objects.filter(pk=self.first.pk).update(content_html='<p>Un texto diferente.</p>')
        self.assertFalse(self.reader_map(0, 1)['available'])
        revision.refresh_from_db()
        self.assertEqual(revision.status, 'stale')
        with self.assertRaises(ValidationError):
            publish_revision(revision, self.staff, restore=True)

    def test_no_characters_requires_reason_and_review(self):
        revision = self.draft({'characters': [], 'relationships': [], 'merges': []})
        with self.assertRaises(ValidationError):
            approve_revision(revision, self.staff)
        approve_revision(revision, self.staff, no_characters=True, reason='El texto no contiene personajes identificables.')
        revision.refresh_from_db()
        publish_revision(revision, self.staff)
        self.assertFalse(self.reader_map(0, 10)['available'])
        revision.refresh_from_db()
        self.assertEqual(revision.status, 'no_characters')

    def test_publish_rolls_back_partial_materialization(self):
        revision = self.draft()
        approve_revision(revision, self.staff)
        revision.refresh_from_db()
        with patch('catalog.character_map_editorial.CharacterFact.objects.get_or_create', side_effect=RuntimeError('storage failure')):
            with self.assertRaises(RuntimeError):
                publish_revision(revision, self.staff)
        self.assertEqual(BookCharacter.objects.filter(revision=revision).count(), 0)
        self.assertFalse(CharacterMapPublication.objects.filter(book=self.book).exists())

    def test_queue_is_repeatable_and_running_jobs_cannot_be_edited(self):
        first, second = queue_book(self.book, self.staff), queue_book(self.book, self.staff)
        self.assertEqual(first.pk, second.pk)
        self.assertEqual(CharacterMapJob.objects.count(), 1)
        with self.assertRaises(ValidationError):
            save_draft(self.book, first.pk, self.payload, self.staff)

    def test_interrupted_generation_cannot_be_approved_as_complete(self):
        revision = queue_book(self.book, self.staff)
        CharacterMapJob.objects.filter(revision=revision).update(status='failed')
        revision.payload, revision.status = validate_payload(self.book, self.payload), 'review'
        revision.save()
        with self.assertRaises(ValidationError):
            approve_revision(revision, self.staff)
        resumed = queue_book(self.book, self.staff, force=True)
        self.assertEqual(resumed.pk, revision.pk)
        self.assertEqual(resumed.job.status, 'queued')

    def test_private_proposal_keeps_curated_legacy_map_visible(self):
        BookCharacter.objects.create(book=self.book, name='Mara', reveal_chapter=self.first, reveal_word=4)
        before = self.reader_map(0, 12)
        queue_book(self.book, self.staff)
        self.assertEqual(self.reader_map(0, 12), before)

    def test_requeue_published_catalog_does_not_duplicate_or_spend(self):
        revision = self.publish()
        again = queue_book(self.book, self.staff)
        self.assertEqual(again.pk, revision.pk)
        self.assertEqual(CharacterMapJob.objects.count(), 0)

    def test_avatar_reassignment_hides_a_previously_approved_portrait(self):
        from ai_engine.models import AIAvatar
        avatar = AIAvatar.objects.create(edition=self.edition, name='Mara', avatar_image='ai_avatars/mara.webp')
        payload = copy.deepcopy(self.payload)
        payload['characters'][0].update(portrait_avatar_id=str(avatar.pk), portrait_evidence=self.ev(self.first, 'Mara llega al jardín.'))
        revision = self.publish(payload)
        self.assertIsNotNone(project_revision(revision, {'chapter': 0, 'word': 12}, self.request)['characters'][0]['portrait_url'])
        avatar.is_author = True
        avatar.save()
        self.assertIsNone(project_revision(revision, {'chapter': 0, 'word': 12}, self.request)['characters'][0]['portrait_url'])

    def test_every_editorial_endpoint_is_staff_only(self):
        self.client.force_authenticate(self.reader)
        for path, method in (('', 'get'), ('budget/', 'get'), ('generate/', 'post'),
                             (f'{self.book.pk}/', 'get'), (f'{self.book.pk}/source/', 'get'),
                             (f'{self.book.pk}/history/', 'get'), (f'{self.book.pk}/approve/', 'post'),
                             (f'{self.book.pk}/publish/', 'post'), (f'{self.book.pk}/preview/', 'post')):
            with self.subTest(path=path):
                self.assertEqual(getattr(self.client, method)(self.base + path).status_code, 403)

    def test_admin_save_approve_publish_and_preview_do_not_change_reader_progress(self):
        self.client.force_authenticate(self.staff)
        response = self.client.patch(self.base + f'{self.book.pk}/', {'revision_id': None, 'payload': self.payload}, format='json')
        self.assertEqual(response.status_code, 200)
        revision_id = response.data['revision']['id']
        preview = self.client.post(self.base + f'{self.book.pk}/preview/', {'revision_id': revision_id, 'chapter': 1, 'word': 17}, format='json')
        self.assertEqual(preview.status_code, 200)
        self.inventory.progress.refresh_from_db()
        self.assertNotEqual(self.inventory.progress.current_cfi, 'word-20')
        self.assertEqual(self.client.post(self.base + f'{self.book.pk}/approve/', {'revision_id': revision_id}, format='json').status_code, 200)
        self.assertEqual(self.client.post(self.base + f'{self.book.pk}/publish/', {'revision_id': revision_id}, format='json').status_code, 200)
        coverage = self.client.get(self.base).data
        self.assertEqual(coverage['coverage']['published'], 1)

    def test_budget_cannot_be_raised_above_authorized_limit(self):
        self.client.force_authenticate(self.staff)
        response = self.client.patch(self.base + 'budget/', {'limit_usd': 101}, format='json')
        self.assertEqual(response.status_code, 400)
