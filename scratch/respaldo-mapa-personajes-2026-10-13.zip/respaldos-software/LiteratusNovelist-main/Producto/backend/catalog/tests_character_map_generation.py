import copy
import io
import json
from datetime import timedelta
from decimal import Decimal
from unittest.mock import patch

from django.core.exceptions import ValidationError
from django.core.management import call_command
from django.db import connection
from django.db.models.query import QuerySet
from django.test import TestCase
from django.utils import timezone

from catalog.character_map_editorial import queue_book, source_snapshot, validate_payload
from catalog.character_map_generation import (
    BudgetUnavailable, GenerationResponse, MAX_OUTPUT_TOKENS,
    PRICING_SOURCE, claim_job, extraction_prompt, fragments, generation_config, input_token_ceiling, merge_payload,
    process_next_job, reserve_call, resume_jobs, settle_call, token_cost,
    validate_fragment, _locked_job,
)
from catalog.models import Book, Chapter, CharacterMapBudget, CharacterMapJob


class FakeExtractor:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []
        self.count_calls = []
        self.output_limits = []

    def count_tokens(self, model, prompt):
        self.count_calls.append((model, prompt))
        return 100

    def generate(self, model, prompt, max_output_tokens=None):
        self.calls.append((model, prompt))
        self.output_limits.append(max_output_tokens)
        result = next(self.responses)
        if isinstance(result, Exception):
            raise result
        if isinstance(result, str):
            return GenerationResponse(result, 100, 50)
        return GenerationResponse(json.dumps(result), 100, 50)


class CharacterMapGenerationTests(TestCase):
    """All provider calls are fakes; fixtures are fictional reader text."""
    def setUp(self):
        retry_sleep = patch('catalog.character_map_generation.time.sleep')
        self.retry_sleep = retry_sleep.start()
        self.addCleanup(retry_sleep.stop)
        self.book = Book.objects.create(title='Obra de pruebas de la cola', is_published=True, status='published')
        self.first = Chapter.objects.create(book=self.book, order=1,
            content_html='<p>Ana llegó al puerto. Bruno saludó a Ana. Ana era capitana del barco.</p>')
        self.second = Chapter.objects.create(book=self.book, order=2,
            content_html='<p>Bruno traicionó a Ana. Ahora eran enemigos.</p>')
        self.budget = CharacterMapBudget.objects.create(name='catalog', pricing_source=PRICING_SOURCE,
            pricing_verified_at=timezone.now(), limit_usd=100)
        self.revision = queue_book(self.book)
        self.empty = {'characters': [], 'relationships': [], 'merges': []}
        self.initial = {'characters': [
            {'key': 'ana', 'name': 'Ana', 'evidence': self.evidence('Ana llegó al puerto.'),
             'facts': [{'key': 'capitana', 'text': 'Es capitana del barco.',
                        'evidence': self.evidence('Ana era capitana del barco.')} ]},
            {'key': 'bruno', 'name': 'Bruno', 'evidence': self.evidence('Bruno saludó a Ana.')},
        ], 'relationships': [{'key': 'saludo', 'source': 'bruno', 'target': 'ana', 'kind': 'other',
                              'label': 'Bruno saluda a Ana', 'evidence': self.evidence('Bruno saludó a Ana.')}],
           'merges': []}

    def evidence(self, quote, chapter=None):
        return {'chapter_id': str((chapter or self.first).pk), 'quote': quote}

    def test_success_saves_fragment_cursor_payload_and_paid_usage_without_publishing(self):
        fake = FakeExtractor([self.initial, self.empty])
        result = process_next_job(extractor=fake)
        self.assertEqual(result['status'], 'done')
        self.revision.refresh_from_db()
        job = self.revision.job
        self.assertEqual(self.revision.status, 'review')
        self.assertIsNone(self.revision.published_at)
        self.assertEqual(job.cursor, 2)
        self.assertEqual(len(job.checkpoints['fragments']), 2)
        self.assertEqual(len(job.checkpoints['calls']), 2)
        self.assertEqual(self.revision.input_tokens, 200)
        self.assertEqual(self.revision.output_tokens, 100)
        self.assertEqual(self.revision.cost_usd, token_cost(100, 50) * 2)
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.reserved_usd, 0)
        self.assertEqual(self.budget.spent_usd, self.revision.cost_usd)
        self.assertEqual(self.revision.payload['characters'][0]['evidence']['end_word'], 3)
        self.assertNotIn('traicionó', fake.calls[0][1])

    def test_pause_at_fragment_resumes_without_duplicate_entries_or_calls(self):
        first = FakeExtractor([self.initial])
        self.assertEqual(process_next_job(extractor=first, max_fragments=1)['status'], 'queued')
        second = FakeExtractor([self.empty])
        self.assertEqual(process_next_job(extractor=second)['status'], 'done')
        self.revision.refresh_from_db()
        self.assertEqual(len(self.revision.payload['characters']), 2)
        self.assertEqual(self.revision.job.attempts, 2)
        self.assertNotIn('Ana llegó al puerto.', json.loads(second.calls[0][1].split('FRAGMENTO=')[1])['text'])

    def test_fragment_manifest_is_frozen_across_worker_defaults_changing(self):
        first = FakeExtractor([self.empty])
        with patch('catalog.character_map_generation.CHUNK_WORDS', 7), patch('catalog.character_map_generation.OVERLAP_WORDS', 2), patch('catalog.character_map_generation.MAX_OUTPUT_TOKENS', 512):
            self.assertEqual(process_next_job(extractor=first, max_fragments=1)['status'], 'queued')
        self.revision.refresh_from_db()
        manifest = self.revision.job.checkpoints['generation_config']
        self.assertEqual((manifest['chunk_words'], manifest['overlap_words'], manifest['max_output_tokens']), (7, 2, 512))
        second = FakeExtractor([self.empty])
        with patch('catalog.character_map_generation.CHUNK_WORDS', 12), patch('catalog.character_map_generation.OVERLAP_WORDS', 1), patch('catalog.character_map_generation.MAX_OUTPUT_TOKENS', 1024):
            self.assertEqual(process_next_job(extractor=second, max_fragments=1)['status'], 'queued')
        fragment = json.loads(second.calls[0][1].split('FRAGMENTO=')[1])
        self.assertEqual(fragment['start_word'], 5)
        self.assertEqual(fragment['end_word'], 11)
        self.assertEqual(first.output_limits, [512])
        self.assertEqual(second.output_limits, [512])
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.job.checkpoints['generation_config'], manifest)
        self.assertTrue(all(call['output_max'] == 512 for call in self.revision.job.checkpoints['calls']))

    def test_cursor_without_legacy_manifest_preserves_original_fragment_boundaries(self):
        self.first.content_html = '<p>' + ' '.join(f'unidad{i}' for i in range(4200)) + '</p>'
        self.first.save()
        self.revision.source_hash = source_snapshot(self.book)[0]
        self.revision.save(update_fields=['source_hash'])
        CharacterMapJob.objects.filter(revision=self.revision).update(cursor=1)
        fake = FakeExtractor([self.empty])
        self.assertEqual(process_next_job(extractor=fake, max_fragments=1)['status'], 'queued')
        fragment = json.loads(fake.calls[0][1].split('FRAGMENTO=')[1])
        self.assertEqual(fragment['start_word'], 3900)
        self.assertEqual(fragment['end_word'], 4199)
        self.assertEqual(fake.output_limits, [4096])
        self.revision.refresh_from_db()
        self.assertTrue(self.revision.job.checkpoints['generation_config']['legacy_cursor'])
        self.assertEqual(self.revision.job.checkpoints['generation_config']['chunk_words'], 4000)

    def test_new_fragment_defaults_and_manifest_saved_even_on_rejected_first_response(self):
        fake = FakeExtractor(['{truncated', '{truncated', '{truncated'])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        manifest = self.revision.job.checkpoints['generation_config']
        self.assertEqual((manifest['chunk_words'], manifest['overlap_words'], manifest['max_output_tokens']), (1600, 100, 8192))
        self.assertEqual(self.revision.job.cursor, 0)
        self.assertEqual(self.revision.job.checkpoints['last_rejected_response'], '{truncated')
        self.assertEqual(self.revision.job.checkpoints['last_rejected_cursor'], 0)

    def test_rejected_raw_response_is_bounded_and_provider_retries_back_off(self):
        raw = '{' + 'x' * 100010
        fake = FakeExtractor([raw, raw, raw])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(len(self.revision.job.checkpoints['last_rejected_response']), 100000)
        resume_jobs(include_failed=True)
        fake = FakeExtractor([RuntimeError('503'), RuntimeError('503'), RuntimeError('503')])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.assertEqual([call.args[0] for call in self.retry_sleep.call_args_list], [10, 20])

    def test_call_reserved_before_generate_and_settled_once(self):
        job = claim_job('worker-test')
        call = reserve_call(job.pk, job.lease_owner, 100, 'prompt')
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.reserved_usd, token_cost(input_token_ceiling('prompt', 100), MAX_OUTPUT_TOKENS))
        settle_call(job.pk, job.lease_owner, call['id'], GenerationResponse('{}', 100, 50))
        settle_call(job.pk, job.lease_owner, call['id'], GenerationResponse('{}', 100, 50))
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.spent_usd, token_cost(100, 50))
        self.assertEqual(self.budget.reserved_usd, 0)

    def test_budget_cap_stops_before_paid_call_and_preserves_cursor(self):
        self.budget.spent_usd = Decimal('99.999')
        self.budget.save()
        fake = FakeExtractor([self.initial])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'paused')
        self.assertEqual(fake.calls, [])
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'budget_paused')
        self.assertEqual(self.revision.job.cursor, 0)
        self.assertEqual(self.revision.job.attempts, 0)

    def test_smaller_limit_cannot_be_bypassed(self):
        self.budget.limit_usd = Decimal('0.001')
        self.budget.save()
        fake = FakeExtractor([self.initial])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'paused')
        self.assertFalse(fake.calls)

    def test_each_retry_is_reserved_and_unknown_provider_error_charged(self):
        fake = FakeExtractor([RuntimeError('provider unavailable'), self.initial, self.empty])
        result = process_next_job(extractor=fake)
        self.assertEqual(result['status'], 'done')
        self.revision.refresh_from_db()
        calls = self.revision.job.checkpoints['calls']
        self.assertEqual(len(calls), 3)
        self.assertEqual(calls[0]['state'], 'unknown')
        self.assertEqual(self.revision.cost_usd, Decimal(calls[0]['reserved_usd']) + token_cost(100, 50) * 2)

    def test_retry_budget_exhaustion_cannot_make_second_paid_call(self):
        prompt = extraction_prompt(fragments([self.first, self.second])[0], self.empty)
        self.budget.limit_usd = token_cost(input_token_ceiling(prompt, 100), MAX_OUTPUT_TOKENS)
        self.budget.save()
        fake = FakeExtractor([RuntimeError('lost response'), self.initial])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'paused')
        self.assertEqual(len(fake.calls), 1)
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.spent_usd, self.budget.limit_usd)

    def test_stale_lease_recovers_lost_reservation_conservatively(self):
        old = claim_job('lost-worker')
        reserved = reserve_call(old.pk, old.lease_owner, 100, 'prompt')
        CharacterMapJob.objects.filter(pk=old.pk).update(lease_until=timezone.now() - timedelta(seconds=1))
        fake = FakeExtractor([self.initial, self.empty])
        self.assertEqual(process_next_job(extractor=fake, owner='new-worker')['status'], 'done')
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.reserved_usd, 0)
        self.assertEqual(self.budget.spent_usd, Decimal(reserved['reserved_usd']) + token_cost(100, 50) * 2)
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.job.checkpoints['calls'][0]['state'], 'unknown')

    def test_invalidated_expired_lease_reconciles_reservation_without_new_generation(self):
        old = claim_job('lost-worker')
        reserved = reserve_call(old.pk, old.lease_owner, 100, 'prompt')
        with self.captureOnCommitCallbacks(execute=True):
            self.first.content_html += '<p>El capítulo fue corregido.</p>'
            self.first.save()
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        CharacterMapJob.objects.filter(pk=old.pk).update(lease_until=timezone.now() - timedelta(seconds=1))
        # Cleanup must also run when current pricing is no longer usable.
        self.budget.refresh_from_db()
        self.budget.pricing_verified_at = None
        self.budget.save()
        fake = FakeExtractor([])
        self.assertEqual(process_next_job(extractor=fake, owner='recovery-worker')['status'], 'failed')
        self.revision.refresh_from_db()
        self.budget.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        self.assertEqual(self.revision.job.status, 'failed')
        self.assertEqual(self.revision.job.cursor, 0)
        self.assertEqual(self.revision.job.checkpoints['calls'][0]['state'], 'unknown')
        self.assertEqual(self.budget.reserved_usd, 0)
        self.assertEqual(self.budget.spent_usd, Decimal(reserved['reserved_usd']))
        self.assertFalse(fake.calls)
        self.assertFalse(fake.count_calls)

    def test_change_between_fragments_stops_before_second_token_count(self):
        fake = FakeExtractor([self.initial, self.empty])
        original_save = CharacterMapJob.save
        def save_then_change(instance, *args, **kwargs):
            result = original_save(instance, *args, **kwargs)
            if 'cursor' in kwargs.get('update_fields', []) and instance.cursor == 1:
                # Bulk updates bypass invalidation signals; the worker must
                # independently check the fingerprint before each fragment.
                Chapter.objects.filter(pk=self.second.pk).update(content_html='<p>Un texto distinto.</p>')
            return result
        with patch.object(CharacterMapJob, 'save', new=save_then_change):
            self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        self.assertEqual(self.revision.job.cursor, 1)
        self.assertEqual(len(fake.calls), 1)
        self.assertEqual(len(fake.count_calls), 1)

    def test_change_during_token_count_prevents_paid_call(self):
        fake = FakeExtractor([])
        def count_and_change(model, prompt):
            Chapter.objects.filter(pk=self.first.pk).update(content_html='<p>Corrección durante el conteo.</p>')
            return 100
        fake.count_tokens = count_and_change
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        self.assertEqual(self.revision.job.attempts, 0)
        self.assertFalse(fake.calls)

    def test_change_after_last_fragment_preserves_stale_instead_of_review(self):
        fake = FakeExtractor([self.initial, self.empty])
        original_save = CharacterMapJob.save
        def save_then_change(instance, *args, **kwargs):
            result = original_save(instance, *args, **kwargs)
            if 'cursor' in kwargs.get('update_fields', []) and instance.cursor == 2:
                Chapter.objects.filter(pk=self.second.pk).update(content_html='<p>Un final distinto.</p>')
            return result
        with patch.object(CharacterMapJob, 'save', new=save_then_change):
            self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        self.assertEqual(self.revision.job.status, 'failed')

    def test_live_lease_prevents_second_worker_claim(self):
        job = claim_job('first')
        self.assertIsNotNone(job)
        self.assertIsNone(claim_job('second'))
        self.assertIsNone(process_next_job(extractor=FakeExtractor([])))

    def test_postgresql_job_locks_target_only_job_including_joined_claim(self):
        calls = []
        original_lock = QuerySet.select_for_update
        def record_lock(queryset, *args, **kwargs):
            if queryset.model is CharacterMapJob:
                calls.append(kwargs)
            return original_lock(queryset, *args, **kwargs)
        # SQLite still executes the test safely; recording the PG capability
        # verifies the explicit lock scope without pretending to test its locks.
        with patch.object(connection.features, 'has_select_for_update_of', True), patch.object(QuerySet, 'select_for_update', new=record_lock):
            job = claim_job('pg-lock-scope')
            _locked_job(job.pk, job.lease_owner)
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(call.get('of') == ('self',) for call in calls))

    def test_missing_or_expired_tariff_never_generates(self):
        self.budget.pricing_verified_at = timezone.now() - timedelta(days=31)
        self.budget.save()
        fake = FakeExtractor([self.initial])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'paused')
        self.assertFalse(fake.calls)
        self.budget.pricing_verified_at = timezone.now()
        self.budget.save()
        self.assertEqual(resume_jobs(), 1)

    def test_source_change_fails_closed_before_generation(self):
        self.first.content_html += '<p>Cambio editorial.</p>'
        self.first.save()
        fake = FakeExtractor([self.initial])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'stale')
        self.assertFalse(fake.calls)

    def test_nonexistent_and_future_evidence_is_rejected_and_billed(self):
        bad = copy.deepcopy(self.initial)
        bad['characters'][0]['evidence'] = self.evidence('Bruno traicionó a Ana.', self.second)
        fake = FakeExtractor([bad, bad, bad])
        self.assertEqual(process_next_job(extractor=fake)['status'], 'failed')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.payload['characters'], [])
        self.assertEqual(self.revision.job.cursor, 0)
        self.assertEqual(self.revision.job.attempts, 3)
        self.assertEqual(self.revision.cost_usd, token_cost(100, 50) * 3)

    def test_same_chapter_future_quote_not_in_current_fragment_is_rejected(self):
        piece = {'chapter_id': str(self.first.pk), 'text': 'Ana llegó al puerto.', 'start_word': 0, 'end_word': 3}
        with self.assertRaises(ValidationError):
            validate_fragment(self.initial, piece, self.empty)

    def test_empty_optional_anchors_are_omitted_but_required_or_partial_empty_fail(self):
        delta = copy.deepcopy(self.initial)
        delta['characters'][0]['until_evidence'] = {'chapter_id': '', 'quote': ''}
        delta['characters'][0]['role_evidence'] = {}
        delta['characters'][0]['portrait_evidence'] = None
        delta['relationships'][0]['until_evidence'] = {'chapter_id': '  ', 'quote': None}
        fragment = fragments([self.first])[0]
        clean = validate_fragment(delta, fragment, self.empty)
        self.assertNotIn('until_evidence', clean['characters'][0])
        self.assertNotIn('role_evidence', clean['characters'][0])
        self.assertNotIn('portrait_evidence', clean['characters'][0])
        self.assertNotIn('until_evidence', clean['relationships'][0])
        validate_payload(self.book, clean)
        for field in ('evidence', 'until_evidence'):
            bad = copy.deepcopy(self.initial)
            bad['characters'][0][field] = {'chapter_id': str(self.first.pk), 'quote': ''}
            with self.assertRaises(ValidationError):
                validate_fragment(bad, fragment, self.empty)

    def test_literal_validation_reports_quote_and_position_without_relaxing_punctuation(self):
        bad = copy.deepcopy(self.initial)
        bad['characters'][0]['evidence']['quote'] = 'Ana llegó al puerto'
        with self.assertRaises(ValidationError) as error:
            validate_fragment(bad, fragments([self.first])[0], self.empty)
        self.assertIn('Ana llegó al puerto', str(error.exception))
        self.assertIn('word-0', str(error.exception))
        self.assertIn('párrafo', str(error.exception))

    def test_repeated_citation_is_rejected_by_editorial_validator(self):
        self.first.content_html = '<p>Ana llegó al puerto. Ana llegó al puerto.</p>'
        self.first.save()
        with self.assertRaises(ValidationError):
            validate_payload(self.book, {'characters': [{'key': 'ana', 'name': 'Ana',
                                                       'evidence': self.evidence('Ana llegó al puerto.')} ]})

    def test_chunk_overlap_and_inactive_chapter_skip(self):
        pieces = fragments([self.first, self.second], chunk_words=7, overlap=2)
        self.assertEqual(pieces[0]['start_word'], 0)
        self.assertEqual(pieces[1]['start_word'], 5)
        self.assertEqual(pieces[0]['text'].split()[-2:], pieces[1]['text'].split()[:2])
        self.second.is_active = False
        self.second.save()
        self.assertTrue(all(piece['chapter_id'] == str(self.first.pk) for piece in fragments([self.first, self.second])))

    def test_merge_deduplicates_normalized_facts_and_preserves_initial_name(self):
        original = validate_payload(self.book, self.initial)
        merged = merge_payload(original, self.initial)
        self.assertEqual(len(merged['characters']), 2)
        self.assertEqual(len(merged['characters'][0]['facts']), 1)
        self.assertEqual(len(merged['relationships']), 1)
        changed = {'characters': [{'key': 'ana', 'name': 'NOMBRE FUTURO'}]}
        with self.assertRaises(ValidationError):
            merge_payload(original, changed)

    def test_empty_work_remains_private_review_instead_of_auto_certifying_absence(self):
        self.assertEqual(process_next_job(extractor=FakeExtractor([self.empty, self.empty]))['status'], 'done')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'review')
        self.assertNotIn('no_characters_reason', self.revision.payload)

    def test_dry_run_commands_make_no_database_or_provider_changes(self):
        output = io.StringIO()
        with patch('catalog.character_map_generation.GeminiExtractor') as sdk:
            call_command('character_map_worker', dry_run=True, verify_pricing=True, resume=True, stdout=output)
            call_command('queue_character_maps', all=True, dry_run=True, stdout=output)
        sdk.assert_not_called()
        self.assertEqual(CharacterMapJob.objects.count(), 1)
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'pending')
        self.budget.refresh_from_db()
        self.assertEqual(self.budget.spent_usd, 0)

    def test_pilot_selection_accepts_catalogue_alicia_title_and_prioritizes_all_three(self):
        titles = ['La metamorfosis', 'Las Aventuras de Alicia en el País de las Maravillas', 'Orgullo y prejuicio']
        for index, title in enumerate(titles):
            book = Book.objects.create(title=title, is_published=True, status='published')
            Chapter.objects.create(book=book, order=1, content_html='<p>' + 'Una persona avanza. ' * (20 + index) + '</p>')
        output = io.StringIO()
        call_command('queue_character_maps', pilots=True, dry_run=True, stdout=output)
        text = output.getvalue()
        self.assertNotIn(self.book.title, text)
        self.assertTrue(all(title in text for title in titles))
        self.assertIn('Candidatos: 3', text)
        self.assertEqual(CharacterMapJob.objects.count(), 1)
        output = io.StringIO()
        call_command('queue_character_maps', all=True, dry_run=True, stdout=output)
        text = output.getvalue()
        order = [text.index(title) for title in titles] + [text.index(self.book.title)]
        self.assertEqual(order, sorted(order))



class CharacterMapAutoModeTests(CharacterMapGenerationTests.__bases__[0]):
    """Modo automático (character_map_worker --auto): mismas fixtures ficticias y extractor falso."""
    setUp = CharacterMapGenerationTests.setUp
    evidence = CharacterMapGenerationTests.evidence

    def test_tolerant_quotes_are_rewritten_to_the_exact_text_and_published(self):
        loose = {'characters': [
            {'key': 'Ana', 'name': 'Ana', 'evidence': self.evidence('«ana llego al puerto»'),
             'facts': [{'key': 'capitana', 'text': 'Es capitana del barco.', 'evidence': self.evidence('Ana era capitana del barco')}]},
            {'key': 'bruno', 'name': 'Bruno', 'evidence': self.evidence('BRUNO SALUDÓ A ANA')},
        ], 'relationships': [{'key': 'saludo', 'source': 'bruno', 'target': 'ana', 'kind': 'other',
                              'label': 'Bruno saluda a Ana', 'evidence': self.evidence('Bruno saludó a Ana')}], 'merges': []}
        result = process_next_job(extractor=FakeExtractor([loose, self.empty]), auto=True)
        self.assertEqual(result['status'], 'done')
        self.assertTrue(result['published'])
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.status, 'published')
        ana = next(c for c in self.revision.payload['characters'] if c['key'] == 'ana')
        self.assertEqual(ana['evidence']['quote'], 'Ana llegó al puerto.')
        self.assertEqual(len(self.revision.payload['relationships']), 1)

    def test_only_the_invalid_proposal_is_dropped(self):
        mixed = copy.deepcopy(self.initial)
        mixed['characters'].append({'key': 'zoe', 'name': 'Zoe', 'evidence': self.evidence('Zoe no existe en este texto')})
        mixed['relationships'].append({'key': 'futuro', 'source': 'bruno', 'target': 'ana', 'kind': 'enemy',
                                       'label': 'Enemigos', 'evidence': self.evidence('Bruno traicionó a Ana.', self.second)})
        process_next_job(extractor=FakeExtractor([mixed, self.empty]), auto=True)
        self.revision.refresh_from_db()
        keys = {c['key'] for c in self.revision.payload['characters']}
        self.assertEqual(keys, {'ana', 'bruno'})
        self.assertEqual([r['key'] for r in self.revision.payload['relationships']], ['saludo'])

    def test_repeated_bad_responses_skip_the_fragment_instead_of_failing_the_book(self):
        fake = FakeExtractor(['{roto', '{roto', '{roto', self.empty])
        result = process_next_job(extractor=fake, auto=True)
        self.assertEqual(result['status'], 'done')
        self.revision.refresh_from_db()
        self.assertIn('0', self.revision.job.checkpoints['skipped'])
        self.assertEqual(self.revision.status, 'review')  # sin personajes no se publica solo

    def test_rate_limit_is_not_billed_nor_counted_as_an_attempt(self):
        class RateLimited(Exception):
            code = 429
        fake = FakeExtractor([RateLimited('429 RESOURCE_EXHAUSTED'), self.initial, self.empty])
        result = process_next_job(extractor=fake, auto=True)
        self.assertEqual(result['status'], 'done')
        self.revision.refresh_from_db()
        self.assertEqual(self.revision.cost_usd, token_cost(100, 50) * 2)
        self.assertNotIn('skipped', self.revision.job.checkpoints)

    def test_compact_prompt_omits_previous_quotes(self):
        payload = validate_payload(self.book, self.initial)
        prompt = extraction_prompt({'chapter_id': str(self.second.pk), 'start_word': 0, 'end_word': 5,
                                    'text': 'Bruno traicionó a Ana.'}, payload, compact=True)
        previous = prompt.split('DATOS_PREVIOS=')[1].split('\nFRAGMENTO=')[0]
        self.assertIn('capitana', previous)
        self.assertNotIn('quote', previous)
