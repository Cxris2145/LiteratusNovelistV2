import json
import tempfile
from datetime import date
from unittest.mock import patch

from django.contrib import admin
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import RequestFactory, override_settings
from rest_framework.test import APITestCase

from ai_engine.models import AIAvatar
from catalog.admin import BookCharacterAdmin
from catalog.models import Book, BookCharacter, Chapter, CharacterFact, CharacterRelationship, Edition
from library.models import ReadingProgress, UserInventory


class CharacterMapTests(APITestCase):
    """Only fictional test fixtures: no literary facts are generated or seeded."""
    def setUp(self):
        self.user = get_user_model().objects.create_user('map-reader', email='map@example.com', password='test')
        self.other = get_user_model().objects.create_user('other-reader', email='other@example.com', password='test')
        self.user.profile.birth_date = date(1990, 1, 1)
        self.user.profile.save(update_fields=['birth_date'])
        self.book = Book.objects.create(title='Obra de prueba del mapa', status='published', is_published=True)
        self.edition = Edition.objects.create(book=self.book, price=0)
        self.inventory = UserInventory.objects.create(user=self.user, edition=self.edition)
        self.progress = self.inventory.progress
        self.progress.current_page = 1
        self.progress.current_cfi = json.dumps({'wordId': 'word-0'})
        self.progress.save(update_fields=['current_page', 'current_cfi'])
        # Non-consecutive orders prove that saved pages are ordinals, not order values.
        self.first = Chapter.objects.create(book=self.book, order=4, content_html='<h1>Inicio</h1><p>uno dos tres cuatro cinco seis siete ocho nueve diez</p>')
        self.second = Chapter.objects.create(book=self.book, order=20, content_html='<p>uno dos tres cuatro cinco seis siete ocho nueve diez</p>')
        self.avatar = AIAvatar.objects.create(edition=self.edition, name='NOMBRE DEL AVATAR NO CURADO',
                                             description='DESCRIPCION FUTURA DEL AVATAR', system_prompt='SECRETO IA',
                                             avatar_image='ai_avatars/portrait.jpg')
        self.a = BookCharacter.objects.create(book=self.book, name='Alicia de prueba', avatar=self.avatar,
                                             reveal_chapter=self.first, reveal_word=1,
                                             portrait_reveal_chapter=self.first, portrait_reveal_word=3,
                                             role='protagonist', role_reveal_chapter=self.first, role_reveal_word=5)
        self.b = BookCharacter.objects.create(book=self.book, name='Bruno de prueba', reveal_chapter=self.first, reveal_word=2,
                                             role='antagonist', role_reveal_chapter=self.second, role_reveal_word=8)
        self.hidden = BookCharacter.objects.create(book=self.book, name='IDENTIDAD FUTURA',
                                                  reveal_chapter=self.second, reveal_word=3)
        self.fact = CharacterFact.objects.create(character=self.a, text='Dato conocido de prueba',
                                                reveal_chapter=self.first, reveal_word=4)
        self.future_fact = CharacterFact.objects.create(character=self.a, text='GIRO DE LA TRAMA FUTURO',
                                                       reveal_chapter=self.second, reveal_word=9)
        self.relation = CharacterRelationship.objects.create(book=self.book, source=self.a, target=self.b,
                                                            kind='friend', label='Amigos de prueba',
                                                            reveal_chapter=self.first, reveal_word=6)
        self.hidden_relation = CharacterRelationship.objects.create(book=self.book, source=self.a, target=self.hidden,
                                                                   kind='family', label='PARENTESCO SECRETO',
                                                                   reveal_chapter=self.first, reveal_word=0)
        self.url = f'/api/v1/library/inventory/{self.inventory.pk}/character-map/'
        self.client.force_authenticate(self.user)

    def move(self, chapter=1, word=0):
        self.progress.current_page = chapter
        self.progress.current_cfi = json.dumps({'wordId': f'word-{word}'})
        self.progress.save(update_fields=['current_page', 'current_cfi'])

    def data(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        return response.data

    def test_before_first_appearance_omits_every_identity_and_count(self):
        data = self.data()
        self.assertEqual(data, {'characters': [], 'relationships': [], 'position': {'chapter': 0, 'word': 0}, 'available': True})
        body = json.dumps(data)
        for secret in ('Alicia', 'Bruno', 'IDENTIDAD FUTURA', str(self.hidden.pk), str(self.hidden_relation.pk), 'total', 'locked', 'reveal'):
            self.assertNotIn(secret, body)

    def test_name_portrait_role_facts_and_relationship_unlock_independently_at_exact_word(self):
        self.move(word=1)
        character = self.data()['characters'][0]
        self.assertEqual(character, {'id': str(self.a.pk), 'name': self.a.name, 'portrait_url': None, 'role': None, 'facts': []})
        self.move(word=2)
        self.assertEqual(len(self.data()['characters']), 2)
        self.assertIsNone(self.data()['characters'][0]['portrait_url'])
        self.move(word=3)
        self.assertTrue(self.data()['characters'][0]['portrait_url'].endswith('/ai_avatars/portrait.jpg'))
        self.assertEqual(self.data()['characters'][0]['facts'], [])
        self.move(word=4)
        self.assertEqual(self.data()['characters'][0]['facts'], [{'id': str(self.fact.pk), 'text': self.fact.text}])
        self.assertIsNone(self.data()['characters'][0]['role'])
        self.move(word=5)
        self.assertEqual(self.data()['characters'][0]['role'], 'protagonist')
        self.assertEqual(self.data()['relationships'], [])
        self.move(word=6)
        self.assertEqual(self.data()['relationships'], [{'id': str(self.relation.pk), 'source_id': str(self.a.pk),
                                                       'target_id': str(self.b.pk), 'kind': 'friend', 'label': self.relation.label}])
        body = json.dumps(self.data())
        for secret in ('antagonist', self.hidden.name, self.future_fact.text, self.hidden_relation.label,
                       self.avatar.name, self.avatar.description, self.avatar.system_prompt):
            self.assertNotIn(secret, body)

    def test_new_chapter_does_not_reveal_its_unread_remainder(self):
        self.move(chapter=2, word=0)
        data = self.data()
        self.assertEqual(data['position'], {'chapter': 1, 'word': 0})
        self.assertEqual(len(data['characters']), 2)
        self.assertIsNone(data['characters'][1]['role'])
        self.assertNotIn(self.future_fact.text, json.dumps(data))
        self.move(chapter=2, word=3)
        self.assertEqual(len(self.data()['characters']), 3)
        self.move(chapter=2, word=8)
        self.assertEqual(self.data()['characters'][1]['role'], 'antagonist')
        self.assertNotIn(self.future_fact.text, json.dumps(self.data()))
        self.move(chapter=2, word=9)
        self.assertIn(self.future_fact.text, json.dumps(self.data()))

    def test_current_position_controls_rereading(self):
        self.move(chapter=2, word=9)
        self.assertEqual(len(self.data()['characters']), 3)
        self.move(chapter=1, word=1)
        self.assertEqual(len(self.data()['characters']), 1)
        self.assertIsNone(self.data()['characters'][0]['role'])

    def test_no_saved_progress_reveals_nothing(self):
        self.progress.delete()
        self.assertEqual(self.data()['position'], {'chapter': -1, 'word': -1})
        self.assertEqual(self.data()['characters'], [])

    def test_malformed_and_out_of_bounds_word_never_unlock_current_chapter(self):
        for cfi in ('', 'not-json', '[]', 'null', '{"wordId":null}', '{"wordId":"word--2"}',
                    '{"wordId":"word-999999999"}', '{"wordId":"word-999999999999"}',
                    '{"scrollPercent":1,"percentage":100}'):
            with self.subTest(cfi=cfi):
                self.progress.current_cfi = cfi
                self.progress.completion_percentage = 100
                self.progress.save(update_fields=['current_cfi', 'completion_percentage'])
                self.assertEqual(self.data()['position'], {'chapter': 0, 'word': -1})
                self.assertEqual(self.data()['characters'], [])

    def test_invalid_chapter_never_clamps_to_last_chapter(self):
        for chapter in (0, 3, 999):
            with self.subTest(chapter=chapter):
                self.move(chapter=chapter, word=9)
                self.assertEqual(self.data()['position'], {'chapter': -1, 'word': -1})
                self.assertEqual(self.data()['characters'], [])

    def test_query_params_cannot_replace_saved_progress(self):
        response = self.client.get(self.url + '?chapter=20&word=99&progress=100&inventory=' + str(self.inventory.pk))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['characters'], [])

    def test_authentication_owner_age_and_deleted_inventory_are_enforced(self):
        self.client.force_authenticate(None)
        self.assertIn(self.client.get(self.url).status_code, (401, 403))
        self.client.force_authenticate(self.other)
        self.assertEqual(self.client.get(self.url).status_code, 404)
        self.client.force_authenticate(self.user)
        self.book.min_age = 18
        self.book.save(update_fields=['min_age'])
        self.user.profile.birth_date = date(2020, 1, 1)
        self.user.profile.save(update_fields=['birth_date'])
        self.assertEqual(self.client.get(self.url).status_code, 403)
        self.book.min_age = 0
        self.book.save(update_fields=['min_age'])
        self.inventory.delete()
        self.assertEqual(self.client.get(self.url).status_code, 404)

    def test_response_is_personal_and_not_cacheable(self):
        response = self.client.get(self.url)
        self.assertIn('private', response['Cache-Control'])
        self.assertIn('no-store', response['Cache-Control'])
        self.assertIn('Authorization', response['Vary'])
        self.assertIn('Cookie', response['Vary'])

    def test_no_curated_data_has_explicit_empty_state(self):
        BookCharacter.objects.filter(book=self.book).update(is_active=False)
        self.assertFalse(self.data()['available'])
        self.assertEqual(self.data()['characters'], [])
        self.assertEqual(self.data()['relationships'], [])

    def test_inactive_chapters_do_not_shift_saved_ordinals_into_future(self):
        Chapter.objects.filter(pk=self.first.pk).update(is_active=False)
        self.move(chapter=1, word=9)
        self.assertEqual(self.data()['position'], {'chapter': -1, 'word': -1})
        self.assertEqual(self.data()['characters'], [])
        self.move(chapter=2, word=0)
        self.assertEqual(self.data()['position'], {'chapter': 1, 'word': 0})
        self.assertEqual(self.data()['characters'], [])

    def test_editorial_writes_reject_cross_book_chapters_characters_and_avatars(self):
        other_book = Book.objects.create(title='Otra obra de prueba')
        other_chapter = Chapter.objects.create(book=other_book, order=1, content_html='<p>uno dos tres</p>')
        other_edition = Edition.objects.create(book=other_book, price=0)
        other_avatar = AIAvatar.objects.create(edition=other_edition, name='Avatar ajeno', system_prompt='test')
        other_character = BookCharacter.objects.create(book=other_book, name='Otro personaje', reveal_chapter=other_chapter)
        invalid = [
            BookCharacter(book=self.book, name='No válido', reveal_chapter=other_chapter),
            BookCharacter(book=self.book, name='No válido', reveal_chapter=self.first, avatar=other_avatar),
            CharacterFact(character=self.a, text='No válido', reveal_chapter=other_chapter),
            CharacterRelationship(book=self.book, source=self.a, target=other_character, kind='family', label='No válido', reveal_chapter=self.first),
            CharacterRelationship(book=self.book, source=self.a, target=self.b, kind='family', label='No válido', reveal_chapter=other_chapter),
            CharacterRelationship(book=self.book, source=self.a, target=self.a, kind='family', label='No válido', reveal_chapter=self.first),
        ]
        for entry in invalid:
            with self.subTest(model=type(entry).__name__):
                with self.assertRaises(ValidationError):
                    entry.save()

    def test_editorial_role_requires_threshold_and_word_must_exist(self):
        with self.assertRaises(ValidationError):
            BookCharacter.objects.create(book=self.book, name='Rol sin límite', reveal_chapter=self.first, role='antagonist')
        with self.assertRaises(ValidationError):
            CharacterFact.objects.create(character=self.a, text='Fuera del capítulo', reveal_chapter=self.first, reveal_word=100)
        self.avatar.is_author = True
        self.avatar.save(update_fields=['is_author'])
        with self.assertRaises(ValidationError):
            BookCharacter.objects.create(book=self.book, name='Autor como personaje', reveal_chapter=self.first, avatar=self.avatar)

    def test_projection_defends_against_unvalidated_bulk_cross_book_data(self):
        other_book = Book.objects.create(title='Libro ajeno')
        other_chapter = Chapter.objects.create(book=other_book, order=1, content_html='<p>uno dos</p>')
        CharacterFact.objects.filter(pk=self.fact.pk).update(reveal_chapter=other_chapter)
        BookCharacter.objects.filter(pk=self.a.pk).update(role_reveal_chapter=other_chapter, portrait_reveal_chapter=other_chapter)
        CharacterRelationship.objects.filter(pk=self.relation.pk).update(reveal_chapter=other_chapter)
        self.move(word=9)
        data = self.data()
        self.assertEqual(data['characters'][0]['facts'], [])
        self.assertIsNone(data['characters'][0]['role'])
        self.assertIsNone(data['characters'][0]['portrait_url'])
        self.assertEqual(data['relationships'], [])

    def test_uploaded_portrait_is_synced_to_configured_public_storage_and_still_gated(self):
        with tempfile.TemporaryDirectory() as directory, override_settings(
                MEDIA_ROOT=directory, MEDIA_URL='https://storage.example/media/'):
            request = RequestFactory().post('/admin/catalog/bookcharacter/', {
                'portrait': SimpleUploadedFile('editorial.png', b'preview-image-bytes', content_type='image/png'),
            })
            self.a.portrait = request.FILES['portrait']
            with patch('core.storage.upload_to_supabase_if_configured', return_value=True) as upload:
                BookCharacterAdmin(BookCharacter, admin.site).save_model(request, self.a, None, True)
            upload.assert_called_once_with(b'preview-image-bytes', self.a.portrait.name, 'image/png', upsert=True)
            self.move(word=1)
            self.assertIsNone(self.data()['characters'][0]['portrait_url'])
            self.move(word=3)
            self.assertTrue(self.data()['characters'][0]['portrait_url'].startswith('https://storage.example/media/character_map/'))
