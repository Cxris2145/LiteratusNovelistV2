"""Queue editorial extraction; this command makes no paid API requests."""
import unicodedata

from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.db.models import Prefetch, Q

from catalog.character_map_editorial import queue_book
from catalog.models import Book, Chapter
from catalog.narration import chapter_words

PILOTS = ('la metamorfosis', 'alicia en el pais de las maravillas', 'orgullo y prejuicio')


def normalized_title(title):
    return ''.join(c for c in unicodedata.normalize('NFKD', title.lower()) if not unicodedata.combining(c)).strip()


class Command(BaseCommand):
    help = 'Encola mapas del catálogo publicado, pilotos primero y después por longitud; no llama a IA.'

    def add_arguments(self, parser):
        selection = parser.add_mutually_exclusive_group(required=True)
        selection.add_argument('--all', action='store_true', help='Todo el catálogo activo publicado.')
        selection.add_argument('--pilots', action='store_true', help='Las tres obras de validación inicial.')
        selection.add_argument('--book', action='append', dest='books', help='UUID de obra; se puede repetir.')
        parser.add_argument('--limit', type=int)
        parser.add_argument('--dry-run', action='store_true', help='Inspecciona sin crear revisiones ni trabajos.')

    def handle(self, *args, **options):
        if options['limit'] is not None and options['limit'] < 1:
            raise CommandError('--limit debe ser positivo.')
        books = Book.objects.filter(is_active=True).filter(Q(status='published') | Q(is_published=True))
        if options['books']:
            try:
                books = books.filter(pk__in=options['books'])
            except (ValueError, ValidationError) as error:
                raise CommandError('Usa UUID válidos en --book.') from error
        if options['pilots']:
            # Narrow candidates before loading chapter HTML from the catalogue.
            # Editorial titles can include prefixes such as "Las Aventuras de".
            books = books.filter(Q(title__icontains='metamorfosis') | Q(title__icontains='alicia')
                                 | Q(title__icontains='orgullo y prejuicio'))
        books = books.prefetch_related(Prefetch('chapters', queryset=Chapter.objects.filter(
            is_active=True).only('id', 'book_id', 'order', 'content_html', 'is_active', 'deleted_at').order_by('order')))
        candidates, empty = [], 0
        for book in books:
            title = normalized_title(book.title)
            pilot = next((i for i, name in enumerate(PILOTS) if name in title), None)
            if options['pilots'] and pilot is None:
                continue
            count = sum(len(chapter_words(chapter.content_html)[0]) for chapter in book.chapters.all())
            if not count:
                empty += 1
                self.stdout.write(f'Sin texto activo: {book.title} ({book.pk})')
                continue
            candidates.append((pilot if pilot is not None else len(PILOTS), count, str(book.pk), book))
        candidates.sort(key=lambda candidate: candidate[:3])
        if options['limit'] is not None:
            candidates = candidates[:options['limit']]
        queued = 0
        for _, count, _, book in candidates:
            if options['dry_run']:
                self.stdout.write(f'{count:>8} palabras · {book.title} · {book.pk}')
                continue
            try:
                revision = queue_book(book)
            except ValidationError as error:
                self.stderr.write(f'{book.title}: {error}')
                continue
            if isinstance(revision, tuple):
                revision = revision[0]
            queued += 1
            self.stdout.write(f'{book.title} · revisión {revision.pk} · {revision.status} · {count} palabras')
        self.stdout.write(self.style.SUCCESS(
            f"{'Candidatos' if options['dry_run'] else 'Revisiones registradas'}: {len(candidates) if options['dry_run'] else queued}; sin texto: {empty}."))

