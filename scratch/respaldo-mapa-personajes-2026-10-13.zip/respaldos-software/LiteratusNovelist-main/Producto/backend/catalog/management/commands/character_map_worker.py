"""Independent durable worker, explicitly bounded by the shared US$100 ledger."""
import json

from django.core.management.base import BaseCommand, CommandError

from catalog.character_map_generation import (
    BudgetUnavailable, process_next_job, resume_jobs, verified_budget,
)
from catalog.models import CharacterMapBudget, CharacterMapJob


class Command(BaseCommand):
    help = 'Procesa la cola editorial de mapas con Gemini y un presupuesto acumulado máximo de US$100.'

    def add_arguments(self, parser):
        parser.add_argument('--max-jobs', type=int, default=1, help='Número máximo de obras; 0 recorre la cola actual.')
        parser.add_argument('--max-fragments', type=int, help='Pausa cada obra después de este número de fragmentos correctos.')
        parser.add_argument('--verify-pricing', action='store_true', help='Registra la tarifa oficial verificada incluida con esta versión.')
        parser.add_argument('--resume', action='store_true', help='Reanuda trabajos pausados por configuración o presupuesto.')
        parser.add_argument('--retry-failed', action='store_true', help='Reanuda fallos explícitamente conservando cursor y costes.')
        parser.add_argument('--dry-run', action='store_true', help='Muestra cola y presupuesto sin modificar ni contactar a Gemini.')
        parser.add_argument('--auto', action='store_true',
                            help='Modo automático: citas tolerantes, salta fragmentos fallidos y publica los mapas que validan.')

    def handle(self, *args, **options):
        if options['max_jobs'] < 0 or (options['max_fragments'] is not None and options['max_fragments'] < 1):
            raise CommandError('Los límites deben ser positivos; --max-jobs 0 significa toda la cola.')
        if options['dry_run']:
            budget = CharacterMapBudget.objects.filter(name='catalog').first()
            self.stdout.write(json.dumps({
                'queued': CharacterMapJob.objects.filter(status='queued').count(),
                'running': CharacterMapJob.objects.filter(status='running').count(),
                'paused': CharacterMapJob.objects.filter(status='paused').count(),
                'failed': CharacterMapJob.objects.filter(status='failed').count(),
                'budget': {'limit': str(budget.limit_usd), 'spent': str(budget.spent_usd),
                           'reserved': str(budget.reserved_usd), 'model': budget.model,
                           'pricing_verified_at': str(budget.pricing_verified_at)} if budget else None,
            }, ensure_ascii=False))
            return
        if options['verify_pricing']:
            try:
                budget = verified_budget()
            except BudgetUnavailable as error:
                raise CommandError(str(error)) from error
            self.stdout.write(f'Tarifa {budget.model} registrada · fuente {budget.pricing_source} · fecha {budget.pricing_verified_at}')
        if options['resume'] or options['retry_failed']:
            self.stdout.write(f"Trabajos reanudados: {resume_jobs(include_failed=options['retry_failed'])}")
        # A finite initial snapshot prevents --max-fragments from cycling the
        # same requeued work forever when --max-jobs=0.
        limit = options['max_jobs'] or CharacterMapJob.objects.filter(status__in=['queued', 'running']).count()
        done = 0
        while done < limit:
            result = process_next_job(max_fragments=options['max_fragments'], auto=options['auto'])
            if result is None:
                break
            self.stdout.write(json.dumps(result, ensure_ascii=False))
            done += 1
            if result['status'] == 'paused':
                # Preserve remaining queue without hammering missing credentials
                # or the same exhausted global budget once per book.
                break
        self.stdout.write(f'Trabajos procesados: {done}.' + ('' if options['auto'] else ' Ninguna revisión fue publicada automáticamente.'))
