"""Evidence-backed editorial revisions. This module never calls an AI provider."""
import copy
import functools
import hashlib
import json
import re
import uuid

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import (Book, BookCharacter, Chapter, CharacterFact, CharacterMapJob,
                     CharacterMapPublication, CharacterMapRevision, CharacterRelationship)
from .narration import chapter_words

EMPTY_PAYLOAD = {'characters': [], 'relationships': [], 'merges': []}
ROLES = {'protagonist', 'antagonist', 'supporting'}
KINDS = {'family', 'friend', 'enemy', 'ally', 'other'}


def source_snapshot(book):
    # Include deleted/inactive chapters: inserting, removing or reordering one changes
    # the ordinal saved by the reader, even when its text isn't currently displayed.
    all_chapters = list(Chapter.all_objects.filter(book=book).order_by('order', 'id'))
    source = [(str(c.pk), c.order, c.title, c.is_active, str(c.deleted_at), c.content_html) for c in all_chapters]
    digest = hashlib.sha256(json.dumps(source, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
    # The reader excludes soft-deleted rows but keeps inactive rows in its ordinal.
    return digest, [c for c in all_chapters if not c.deleted_at]


@functools.lru_cache(maxsize=128)
def cached_chapter_words(content_html):
    """chapter_words() por contenido: validar un mapa ancla cientos de citas del mismo capítulo
    y antes volvía a analizar su HTML completo por cada una (lento en obras largas)."""
    return chapter_words(content_html)


def evidence_anchor(evidence, chapters, location='Evidencia'):
    if not isinstance(evidence, dict):
        raise ValidationError(f'{location}: indica un capítulo y una cita literal.')
    chapter_id = str(evidence.get('chapter_id', ''))
    chapter_index = next((i for i, c in enumerate(chapters) if str(c.pk) == chapter_id
                          and c.is_active and not c.deleted_at), None)
    if chapter_index is None:
        raise ValidationError(f'{location}: el capítulo no pertenece al texto activo de este libro.')
    quote = evidence.get('quote')
    if not isinstance(quote, str) or not quote.strip() or len(quote) > 12000:
        raise ValidationError(f'{location}: la cita debe tener entre 1 y 12.000 caracteres.')
    needle = quote.split()
    words, _ = cached_chapter_words(chapters[chapter_index].content_html)
    matches = [i for i in range(len(words) - len(needle) + 1) if words[i:i + len(needle)] == needle]
    if len(matches) != 1:
        reason = 'no existe literalmente en el capítulo' if not matches else 'se repite; amplía el pasaje para identificar una sola aparición'
        raise ValidationError(f'{location}: la cita {reason}.')
    return {'chapter_id': chapter_id, 'quote': ' '.join(needle), 'chapter': chapter_index,
            'start_word': matches[0], 'end_word': matches[0] + len(needle) - 1}


def anchor_position(anchor):
    return anchor['chapter'], anchor['end_word']


def validate_payload(book, payload):
    """Recompute every anchor; never trust model/admin-supplied word offsets."""
    if not isinstance(payload, dict):
        raise ValidationError('El mapa debe ser un objeto.')
    _, chapters = source_snapshot(book)
    result = copy.deepcopy(EMPTY_PAYLOAD)
    errors = []
    keys = set()

    def items(obj, field, limit):
        value = obj.get(field, [])
        if not isinstance(value, list) or len(value) > limit:
            raise ValidationError(f'{field}: lista inválida o demasiado extensa.')
        return value

    def text(obj, field, limit, required=True):
        value = obj.get(field, '')
        if not isinstance(value, str) or len(value) > limit or (required and not value.strip()):
            raise ValidationError(f'{field}: texto inválido (máximo {limit} caracteres).')
        return value.strip()

    def key(obj, seen):
        value = text(obj, 'key', 100)
        if not re.fullmatch(r'[\w.-]+', value) or value in seen:
            raise ValidationError(f'Clave duplicada o inválida: {value}.')
        seen.add(value)
        return value

    def entry(obj, fields, label):
        if not isinstance(obj, dict):
            raise ValidationError(f'{label}: registro inválido.')
        out = {f: text(obj, f, limit) for f, limit in fields.items()}
        out['evidence'] = evidence_anchor(obj.get('evidence'), chapters, label)
        if obj.get('until_evidence'):
            out['until_evidence'] = evidence_anchor(obj['until_evidence'], chapters, f'{label}, final de vigencia')
            if anchor_position(out['until_evidence']) <= anchor_position(out['evidence']):
                raise ValidationError(f'{label}: el final debe ser posterior al inicio.')
        return out

    for raw in items(payload, 'characters', 2000):
        try:
            c = entry(raw, {'name': 255}, 'Identidad')
            c['key'] = key(raw, keys)
            c['names'] = [entry(n, {'name': 255}, f'Nombre de {c["name"]}') for n in items(raw, 'names', 100)]
            c['names'].sort(key=lambda n: anchor_position(n['evidence']))
            if any(anchor_position(n['evidence']) < anchor_position(c['evidence']) for n in c['names']):
                raise ValidationError('Un alias no puede preceder a la primera identidad.')
            c['roles'] = []
            initial_role = raw.get('role')
            if initial_role:
                if initial_role not in ROLES:
                    raise ValidationError('Rol inválido.')
                c['role'] = initial_role
                c['role_evidence'] = evidence_anchor(raw.get('role_evidence'), chapters, 'Rol inicial')
            for r in items(raw, 'roles', 100):
                stage = entry(r, {'role': 16}, 'Cambio de rol')
                if stage['role'] not in ROLES:
                    raise ValidationError('Rol inválido.')
                c['roles'].append(stage)
            c['roles'].sort(key=lambda r: anchor_position(r['evidence']))
            role_points = [anchor_position(r['evidence']) for r in c['roles']]
            if len(set(role_points)) != len(role_points):
                raise ValidationError('Dos roles no pueden comenzar en el mismo punto.')
            fact_keys = set()
            c['facts'] = []
            for f in items(raw, 'facts', 2000):
                fact = entry(f, {'text': 2000}, f'Dato de {c["name"]}')
                fact['key'] = key(f, fact_keys)
                c['facts'].append(fact)
            avatar_id = raw.get('portrait_avatar_id')
            if avatar_id:
                from ai_engine.models import AIAvatar
                avatar = AIAvatar.objects.filter(pk=avatar_id, edition__book=book, is_author=False,
                                                  is_active=True, edition__is_active=True,
                                                  edition__deleted_at__isnull=True).first()
                if not avatar or not avatar.avatar_image:
                    raise ValidationError('El retrato debe pertenecer a un personaje activo de este libro.')
                c['portrait_avatar_id'] = str(avatar.pk)
                c['portrait_evidence'] = evidence_anchor(raw.get('portrait_evidence'), chapters, 'Retrato')
            result['characters'].append(c)
        except (ValidationError, ValueError, TypeError, AttributeError) as exc:
            errors.extend(exc.messages if isinstance(exc, ValidationError) else [str(exc)])
    by_key = {c['key']: c for c in result['characters']}
    relation_keys = set()
    for raw in items(payload, 'relationships', 10000):
        try:
            r = entry(raw, {'source': 100, 'target': 100, 'kind': 12, 'label': 150}, 'Vínculo')
            r['key'] = key(raw, relation_keys)
            if r['kind'] not in KINDS or r['source'] not in by_key or r['target'] not in by_key or r['source'] == r['target']:
                raise ValidationError('El vínculo necesita dos personajes distintos de esta revisión y un tipo válido.')
            result['relationships'].append(r)
        except (ValidationError, ValueError, TypeError) as exc:
            errors.extend(exc.messages if isinstance(exc, ValidationError) else [str(exc)])
    for raw in items(payload, 'merges', 2000):
        try:
            m = entry(raw, {'source': 100, 'target': 100}, 'Unión de identidades')
            if m['source'] not in by_key or m['target'] not in by_key or m['source'] == m['target']:
                raise ValidationError('La unión necesita dos identidades distintas de esta revisión.')
            if any(anchor_position(by_key[k]['evidence']) > anchor_position(m['evidence']) for k in (m['source'], m['target'])):
                raise ValidationError('La unión no puede preceder a una de sus identidades.')
            result['merges'].append(m)
        except (ValidationError, ValueError, TypeError) as exc:
            errors.extend(exc.messages if isinstance(exc, ValidationError) else [str(exc)])
    result['merges'].sort(key=lambda m: anchor_position(m['evidence']))
    # A changing friendship/alliance must have an explicit end before hostility.
    for index, r in enumerate(result['relationships']):
        for other in result['relationships'][index + 1:]:
            if {r['source'], r['target']} != {other['source'], other['target']}:
                continue
            if 'enemy' not in (r['kind'], other['kind']) or not ({r['kind'], other['kind']} & {'friend', 'ally'}):
                continue
            start = max(anchor_position(r['evidence']), anchor_position(other['evidence']))
            end = min(anchor_position(r['until_evidence']) if r.get('until_evidence') else (10**9, 0),
                      anchor_position(other['until_evidence']) if other.get('until_evidence') else (10**9, 0))
            if start < end:
                errors.append('Amistad/alianza y enemistad se superponen: indica su final de vigencia.')
    reason = text(payload, 'no_characters_reason', 2000, required=False)
    if reason:
        result['no_characters_reason'] = reason
    if errors:
        raise ValidationError(errors)
    return result


@transaction.atomic
def queue_book(book, user=None, force=False):
    Book.objects.select_for_update().get(pk=book.pk)
    digest, chapters = source_snapshot(book)
    if not any(c.is_active and not c.deleted_at and chapter_words(c.content_html)[0] for c in chapters):
        raise ValidationError('El libro no tiene capítulos legibles activos.')
    publication = CharacterMapPublication.objects.filter(book=book, revision__source_hash=digest,
        revision__status__in=['published', 'no_characters']).select_related('revision').first()
    if publication and not force:
        return publication.revision
    existing = CharacterMapRevision.objects.filter(book=book, source_hash=digest,
        status__in=['pending', 'generating', 'review', 'approved', 'budget_paused', 'failed']).first()
    if existing:
        job = CharacterMapJob.objects.select_for_update().filter(revision=existing).first()
        if job and job.status in ('failed', 'paused') and force:
            checkpoints = copy.deepcopy(job.checkpoints)
            checkpoints.setdefault('failures', {}).pop(str(job.cursor), None)
            job.status, job.lease_owner, job.lease_until = 'queued', '', None
            job.checkpoints = checkpoints
            job.save()
            existing.status = 'pending'
            existing.save(update_fields=['status', 'updated_at'])
        return existing
    revision = CharacterMapRevision.objects.create(book=book, source_hash=digest, payload=copy.deepcopy(EMPTY_PAYLOAD), requested_by=user)
    CharacterMapJob.objects.create(revision=revision)
    return revision


@transaction.atomic
def save_draft(book, revision_id, payload, user):
    Book.objects.select_for_update().get(pk=book.pk)
    revision = CharacterMapRevision.objects.select_for_update().filter(book=book, pk=revision_id).first() if revision_id else None
    if revision_id and revision is None:
        raise ValidationError('La revisión no pertenece a este libro.')
    if revision and revision.published_at:
        # Published revisions are immutable: editing creates a new independent draft.
        revision = None
    if revision and CharacterMapJob.objects.filter(revision=revision, status__in=['queued', 'running']).exists():
        raise ValidationError('Espera a que termine la generación antes de editar.')
    digest, _ = source_snapshot(book)
    if not revision:
        revision = CharacterMapRevision(book=book, requested_by=user)
    revision.source_hash = digest
    revision.payload = copy.deepcopy(payload)
    revision.errors = []
    try:
        revision.payload = validate_payload(book, payload)
    except ValidationError as exc:
        revision.errors = exc.messages
    revision.status = 'review'
    revision.reviewed_at = None
    revision.reviewed_by = None
    revision.save()
    return revision


@transaction.atomic
def approve_revision(revision, user, no_characters=False, reason=''):
    revision = CharacterMapRevision.objects.select_for_update().get(pk=revision.pk)
    if revision.published_at or revision.status not in ('review', 'failed', 'budget_paused', 'approved'):
        raise ValidationError('La revisión no está lista para revisión editorial.')
    if CharacterMapJob.objects.filter(revision=revision).exclude(status='done').exists():
        raise ValidationError('La generación no completó todos los fragmentos. Reanúdala antes de aprobar esta revisión.')
    digest, _ = source_snapshot(revision.book)
    if digest != revision.source_hash:
        raise ValidationError('El texto ha cambiado; guarda y revisa los nuevos anclajes.')
    payload = copy.deepcopy(revision.payload)
    if no_characters:
        if payload.get('characters') or not str(reason).strip():
            raise ValidationError('Para aprobar sin personajes, elimina los personajes e indica una justificación.')
        payload['no_characters_reason'] = str(reason).strip()
    normalized = validate_payload(revision.book, payload)
    if not normalized['characters'] and not normalized.get('no_characters_reason'):
        raise ValidationError('Un mapa vacío necesita una justificación editorial.')
    revision.payload = normalized
    revision.errors = []
    revision.reviewed_by = user
    revision.reviewed_at = timezone.now()
    revision.status = 'approved'
    revision.save()
    return revision


def stable_id(revision, key):
    return uuid.uuid5(revision.pk, key)


@transaction.atomic
def publish_revision(revision, user, restore=False):
    Book.objects.select_for_update().get(pk=revision.book_id)
    revision = CharacterMapRevision.objects.select_for_update().get(pk=revision.pk)
    if not revision.reviewed_at or (not restore and revision.status != 'approved') or (restore and not revision.published_at):
        raise ValidationError('Aprueba esta revisión antes de publicarla.')
    digest, chapters = source_snapshot(revision.book)
    if digest != revision.source_hash:
        raise ValidationError('El texto fuente ha cambiado; esta revisión no puede publicarse.')
    payload = validate_payload(revision.book, revision.payload)
    if not payload['characters'] and not payload.get('no_characters_reason'):
        raise ValidationError('Un mapa vacío necesita una justificación editorial.')
    by_chapter = {str(c.pk): c for c in chapters}
    characters = {}
    for c in payload['characters']:
        defaults = {'book': revision.book, 'revision': revision, 'name': c['name'],
                    'reveal_chapter': by_chapter[c['evidence']['chapter_id']], 'reveal_word': c['evidence']['end_word']}
        if c.get('portrait_avatar_id'):
            defaults.update(avatar_id=c['portrait_avatar_id'], portrait_reveal_chapter=by_chapter[c['portrait_evidence']['chapter_id']],
                            portrait_reveal_word=c['portrait_evidence']['end_word'])
        if c.get('role'):
            defaults.update(role=c['role'], role_reveal_chapter=by_chapter[c['role_evidence']['chapter_id']],
                            role_reveal_word=c['role_evidence']['end_word'])
        character, _ = BookCharacter.objects.get_or_create(pk=stable_id(revision, 'character:' + c['key']), defaults=defaults)
        characters[c['key']] = character
        for fact in c['facts']:
            CharacterFact.objects.get_or_create(pk=stable_id(revision, f'fact:{c["key"]}:{fact["key"]}'), defaults={
                'revision': revision, 'character': character, 'text': fact['text'],
                'reveal_chapter': by_chapter[fact['evidence']['chapter_id']], 'reveal_word': fact['evidence']['end_word']})
    for r in payload['relationships']:
        CharacterRelationship.objects.get_or_create(pk=stable_id(revision, 'relationship:' + r['key']), defaults={
            'book': revision.book, 'revision': revision, 'source': characters[r['source']], 'target': characters[r['target']],
            'kind': r['kind'], 'label': r['label'], 'reveal_chapter': by_chapter[r['evidence']['chapter_id']], 'reveal_word': r['evidence']['end_word']})
    revision.payload = payload
    revision.status = 'published' if payload['characters'] else 'no_characters'
    revision.published_at = revision.published_at or timezone.now()
    revision.save()
    CharacterMapPublication.objects.update_or_create(book=revision.book, defaults={'revision': revision})
    return revision


def project_revision(revision, position, request):
    """Whitelist public fields, reconstructing only events known at this position."""
    payload = revision.payload
    at = position['chapter'], position['word']

    def visible(evidence):
        return isinstance(evidence, dict) and 'chapter' in evidence and position['chapter'] >= 0 and anchor_position(evidence) <= at

    def current(entry):
        return visible(entry.get('evidence')) and not visible(entry.get('until_evidence'))

    visible_characters = {c['key']: c for c in payload.get('characters', []) if visible(c.get('evidence'))}
    representatives = {key: key for key in visible_characters}

    def representative(key):
        seen = set()
        while key in representatives and representatives[key] != key and key not in seen:
            seen.add(key)
            key = representatives[key]
        return key

    for merge in payload.get('merges', []):
        if visible(merge.get('evidence')) and merge['source'] in visible_characters and merge['target'] in visible_characters:
            source, target = representative(merge['source']), representative(merge['target'])
            if source != target:
                representatives[source] = target
    rows = {str(c.pk): c for c in BookCharacter.objects.filter(revision=revision).select_related('avatar__edition')}
    characters = {}
    for key, c in visible_characters.items():
        rep = representative(key)
        primary = visible_characters[rep]
        public_id = str(stable_id(revision, 'character:' + rep))
        if rep not in characters:
            names = [stage for stage in primary.get('names', []) if visible(stage.get('evidence'))]
            name = names[-1]['name'] if names else primary['name']
            stages = list(primary.get('roles', []))
            if primary.get('role'):
                stages.append({'role': primary['role'], 'evidence': primary.get('role_evidence')})
            stages = sorted([s for s in stages if visible(s.get('evidence'))], key=lambda s: anchor_position(s['evidence']))
            portrait_url = None
            if visible(primary.get('portrait_evidence')):
                row = rows.get(public_id)
                avatar = row.avatar if row else None
                if not row and primary.get('portrait_avatar_id'):
                    from ai_engine.models import AIAvatar
                    avatar = AIAvatar.objects.filter(pk=primary['portrait_avatar_id'], edition__book=revision.book,
                        is_author=False, is_active=True, edition__is_active=True, edition__deleted_at__isnull=True).first()
                if (avatar and avatar.avatar_image and avatar.is_active and not avatar.deleted_at and not avatar.is_author
                        and avatar.edition.book_id == revision.book_id and avatar.edition.is_active and not avatar.edition.deleted_at):
                    portrait_url = request.build_absolute_uri(avatar.avatar_image.url)
            characters[rep] = {'id': public_id, 'name': name, 'portrait_url': portrait_url,
                               'role': stages[-1]['role'] if stages and current(stages[-1]) else None, 'facts': []}
        for fact in c.get('facts', []):
            if current(fact):
                characters[rep]['facts'].append({'id': str(stable_id(revision, f'fact:{key}:{fact["key"]}')), 'text': fact['text']})
    relationships = []
    for r in payload.get('relationships', []):
        if current(r) and r['source'] in visible_characters and r['target'] in visible_characters:
            source, target = representative(r['source']), representative(r['target'])
            if source != target:
                relationships.append({'id': str(stable_id(revision, 'relationship:' + r['key'])),
                    'source_id': characters[source]['id'], 'target_id': characters[target]['id'], 'kind': r['kind'], 'label': r['label']})
    return {'characters': list(characters.values()), 'relationships': relationships,
            'position': position, 'available': bool(payload.get('characters'))}
