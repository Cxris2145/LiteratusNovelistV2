"""Spoiler-safe projection of curated facts at an owner's saved reading position."""
import json
import re

from django.db.models import Prefetch

from .models import BookCharacter, CharacterFact, CharacterRelationship, Chapter, CharacterMapPublication, CharacterMapRevision
from .narration import chapter_words


def saved_position(inventory, chapters):
    """current_page is one-based; word-N and the returned chapter are zero-based.

    Percentages and browser query parameters cannot unlock editorial information.
    Malformed or out-of-range saved positions fail conservatively.
    """
    progress = getattr(inventory, 'progress', None)
    if not progress or progress.deleted_at or not progress.is_active:
        return {'chapter': -1, 'word': -1}
    index = progress.current_page - 1
    if index < 0 or index >= len(chapters) or not chapters[index].is_active:
        return {'chapter': -1, 'word': -1}
    word = -1
    try:
        data = json.loads(progress.current_cfi)
        match = re.fullmatch(r'word-(\d{1,9})', data.get('wordId', '')) if isinstance(data, dict) else None
        if match:
            candidate = int(match.group(1))
            words, _ = chapter_words(chapters[index].content_html)
            if candidate < len(words):
                word = candidate
    except (ValueError, TypeError):
        pass
    return {'chapter': index, 'word': word}


def build_character_map(inventory, request):
    book = inventory.edition.book
    # Match the reader's chapter ordinal exactly, even for legacy inactive rows.
    # Removing an inactive chapter here would turn a saved page into a later page.
    chapters = list(Chapter.objects.filter(book=book).only('id', 'order', 'is_active').order_by('order'))
    chapter_indices = {chapter.pk: i for i, chapter in enumerate(chapters) if chapter.is_active}
    position = saved_position(inventory, chapters)

    publication = CharacterMapPublication.objects.filter(book=book).select_related('revision').first()
    if publication:
        from .character_map_editorial import source_snapshot, project_revision
        revision = publication.revision
        if (revision.source_hash != source_snapshot(book)[0] or revision.status not in ('published', 'no_characters')
                or not revision.is_active or revision.deleted_at):
            if revision.status != 'stale':
                CharacterMapRevision.objects.filter(pk=revision.pk).update(status='stale')
            return {'characters': [], 'relationships': [], 'position': position, 'available': False}
        return project_revision(revision, position, request)

    # A new private proposal must not hide a previously curated legacy map. The
    # legacy queries below explicitly exclude every revision-owned row.

    def revealed(chapter_id, word):
        index = chapter_indices.get(chapter_id)
        if index is None or position['chapter'] < 0:
            return False
        return (index, word) <= (position['chapter'], position['word'])

    curated = list(BookCharacter.objects.filter(book=book, is_active=True, revision__isnull=True).select_related(
        'avatar__edition',
    ).prefetch_related(Prefetch('facts', queryset=CharacterFact.objects.filter(is_active=True))))
    characters = []
    for character in curated:
        if not revealed(character.reveal_chapter_id, character.reveal_word):
            continue
        portrait_url = None
        if revealed(character.portrait_reveal_chapter_id, character.portrait_reveal_word):
            portrait = character.portrait
            avatar = character.avatar
            if not portrait and avatar and avatar.is_active and not avatar.deleted_at and not avatar.is_author:
                if avatar.edition.book_id == book.pk and avatar.edition.is_active and not avatar.edition.deleted_at:
                    portrait = avatar.avatar_image
            if portrait:
                portrait_url = request.build_absolute_uri(portrait.url)
        role = character.role or None
        if not revealed(character.role_reveal_chapter_id, character.role_reveal_word):
            role = None
        facts = [{'id': str(fact.pk), 'text': fact.text} for fact in character.facts.all()
                 if revealed(fact.reveal_chapter_id, fact.reveal_word)]
        characters.append({'id': str(character.pk), 'name': character.name,
                           'portrait_url': portrait_url, 'role': role, 'facts': facts})

    visible_ids = {character['id'] for character in characters}
    relationships = []
    for relation in CharacterRelationship.objects.filter(book=book, is_active=True, revision__isnull=True):
        if (str(relation.source_id) in visible_ids and str(relation.target_id) in visible_ids
                and revealed(relation.reveal_chapter_id, relation.reveal_word)):
            relationships.append({'id': str(relation.pk), 'source_id': str(relation.source_id),
                                  'target_id': str(relation.target_id), 'kind': relation.kind,
                                  'label': relation.label})

    # No locked identities, future thresholds, total counts or AI profile metadata.
    return {'characters': characters, 'relationships': relationships,
            'position': position, 'available': bool(curated)}
