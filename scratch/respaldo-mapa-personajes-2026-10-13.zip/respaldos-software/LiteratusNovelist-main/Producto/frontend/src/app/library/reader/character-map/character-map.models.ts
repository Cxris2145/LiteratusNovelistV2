export type CharacterRole = 'protagonist' | 'antagonist' | 'supporting';
export type CharacterRelationshipKind = 'family' | 'friend' | 'enemy' | 'ally' | 'other';

/** Contains only information already revealed at the saved reading position. */
export interface BookCharacter {
  id: string;
  name: string;
  portrait_url: string | null;
  role: CharacterRole | null;
  facts: { id: string; text: string }[];
}

export interface CharacterRelationship {
  id: string;
  source_id: string;
  target_id: string;
  kind: CharacterRelationshipKind;
  label: string;
}

export interface CharacterMapData {
  characters: BookCharacter[];
  relationships: CharacterRelationship[];
  /** Chapter and word offsets are zero-based; chapter -1 means no saved reading. */
  position: { chapter: number; word: number };
  available: boolean;
}

export interface CharacterGraphNode {
  character: BookCharacter;
  x: number;
  y: number;
}

export interface CharacterGraphEdge {
  relationship: CharacterRelationship;
  path: string;
  labelX: number;
  labelY: number;
  labelWidth: number;
  shortLabel: string;
}

export interface CharacterGraph {
  nodes: CharacterGraphNode[];
  edges: CharacterGraphEdge[];
  width: number;
  height: number;
}

/** Deterministic concentric layout built exclusively from visible characters. */
export function buildCharacterGraph(data: CharacterMapData | null | undefined): CharacterGraph {
  const characters = [...(data?.characters ?? [])].sort((a, b) => {
    const priority = Number(b.role === 'protagonist') - Number(a.role === 'protagonist');
    return priority || a.id.localeCompare(b.id);
  });
  const ringCount = Math.ceil(Math.max(0, characters.length - 1) / 8);
  const radius = Math.max(210, ringCount * 205);
  const width = Math.max(720, radius * 2 + 190);
  const height = Math.max(560, radius * 2 + 185);
  const centerX = width / 2;
  const centerY = height / 2 - 25;
  const nodes: CharacterGraphNode[] = characters.map((character, index) => {
    if (index === 0) return { character, x: centerX, y: centerY };
    const ring = Math.floor((index - 1) / 8) + 1;
    const indexInRing = (index - 1) % 8;
    const countInRing = Math.min(8, characters.length - 1 - (ring - 1) * 8);
    const angle = (-Math.PI / 2) + (indexInRing / countInRing) * Math.PI * 2 + (ring % 2 === 0 ? Math.PI / 8 : 0);
    return {
      character,
      x: centerX + Math.cos(angle) * ring * 205,
      y: centerY + Math.sin(angle) * ring * 205,
    };
  });
  const byId = new Map(nodes.map(node => [node.character.id, node]));
  const relationships = [...(data?.relationships ?? [])].filter(relationship =>
    byId.has(relationship.source_id) && byId.has(relationship.target_id) && relationship.source_id !== relationship.target_id
  ).sort((a, b) => a.id.localeCompare(b.id));
  const pairTotals = new Map<string, number>();
  const pairLabelWidths = new Map<string, number>();
  for (const relationship of relationships) {
    const pair = [relationship.source_id, relationship.target_id].sort().join(':');
    pairTotals.set(pair, (pairTotals.get(pair) ?? 0) + 1);
    pairLabelWidths.set(pair, Math.max(pairLabelWidths.get(pair) ?? 0, graphRelationshipLabel(relationship).labelWidth));
  }
  const pairs = new Map<string, number>();
  const edges: CharacterGraphEdge[] = [];
  for (const relationship of relationships) {
    const source = byId.get(relationship.source_id);
    const target = byId.get(relationship.target_id);
    // Defend against incomplete responses without exposing an unrevealed endpoint.
    if (!source || !target || source === target) continue;
    const pair = [source.character.id, target.character.id].sort().join(':');
    const lane = pairs.get(pair) ?? 0;
    pairs.set(pair, lane + 1);
    const dx = target.x - source.x;
    const dy = target.y - source.y;
    const distance = Math.hypot(dx, dy);
    const direction = source.character.id.localeCompare(target.character.id) <= 0 ? 1 : -1;
    const nx = -dy / distance * direction;
    const ny = dx / distance * direction;
    const laneSpacing = (pairLabelWidths.get(pair) ?? 56) + 18;
    // Keep vertical-link labels away from the name and role below the top portrait.
    const baseBend = Math.abs(dx) < distance * 0.35 ? 220 : 28;
    const bend = (lane % 2 === 0 ? 1 : -1) * ((pairTotals.get(pair) ?? 0) > 1 ? Math.max(baseBend, laneSpacing) * (1 + Math.floor(lane / 2) * 2) : baseBend);
    const controlX = (source.x + target.x) / 2 + nx * bend;
    const controlY = (source.y + target.y) / 2 + ny * bend;
    const { shortLabel, labelWidth } = graphRelationshipLabel(relationship);
    edges.push({
      relationship,
      path: `M ${source.x} ${source.y} Q ${controlX} ${controlY} ${target.x} ${target.y}`,
      labelX: (source.x + target.x) / 2 + nx * bend / 2,
      labelY: (source.y + target.y) / 2 + ny * bend / 2,
      labelWidth,
      shortLabel,
    });
  }
  return { nodes, edges, width, height };
}

function graphRelationshipLabel(relationship: CharacterRelationship): { shortLabel: string; labelWidth: number } {
  const label = relationship.label || relationshipKindLabel(relationship.kind);
  const shortLabel = label.length > 28 ? label.slice(0, 27).trimEnd() + '…' : label;
  return { shortLabel, labelWidth: Math.max(56, shortLabel.length * 7.5 + 20) };
}

export function relationshipKindLabel(kind: CharacterRelationshipKind): string {
  return ({ family: 'Familia', friend: 'Amistad', enemy: 'Enemistad', ally: 'Alianza', other: 'Relación' })[kind];
}
