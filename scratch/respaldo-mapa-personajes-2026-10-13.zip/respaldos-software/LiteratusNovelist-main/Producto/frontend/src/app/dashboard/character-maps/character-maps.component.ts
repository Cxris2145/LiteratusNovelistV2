import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject, takeUntil } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import {
  CharacterMapsService, MapBookDetail, MapBookRow, MapCatalogue, MapCharacter, MapEvidence,
  MapPayload, MapRevision,
} from '../services/character-maps.service';
import { CharacterMapData } from '../../library/reader/character-map/character-map.models';

@Component({
  selector: 'app-character-maps-editor',
  templateUrl: './character-maps.component.html',
  styleUrls: ['./character-maps.component.css']
})
export class CharacterMapsComponent implements OnInit, OnDestroy {
  catalogue: MapCatalogue | null = null;
  detail: MapBookDetail | null = null;
  payload: MapPayload = this.emptyPayload();
  loading = false;
  loadingDetail = false;
  busy = false;
  dirty = false;
  query = '';
  status = '';
  page = 1;
  readonly pageSize = 30;
  selectedKey = '';
  editorTab: 'characters' | 'relationships' | 'merges' | 'preview' = 'characters';
  message = '';
  errors: string[] = [];
  reviewed = false;
  noCharacters = false;
  previewChapter = 0;
  previewWord = 0;
  previewData: CharacterMapData | null = null;
  previewLoading = false;
  previewError = '';
  history: MapRevision[] = [];
  historyOpen = false;
  historyLoading = false;
  queueAllOpen = false;
  pendingBook: MapBookRow | null = null;
  readonly statuses = [
    { value: '', label: 'Todos los estados' }, { value: 'pending', label: 'Pendiente' },
    { value: 'generating', label: 'Generando' }, { value: 'review', label: 'En revisión' },
    { value: 'approved', label: 'Aprobado' },
    { value: 'published', label: 'Publicado' }, { value: 'no_characters', label: 'Sin personajes' },
    { value: 'stale', label: 'Desactualizado' }, { value: 'failed', label: 'Fallido' },
    { value: 'budget_paused', label: 'Pausado por presupuesto' },
  ];
  readonly roles = [{ value: 'protagonist', label: 'Protagonista' }, { value: 'antagonist', label: 'Antagonista' }, { value: 'supporting', label: 'Secundario' }];
  readonly kinds = [{ value: 'family', label: 'Familia' }, { value: 'friend', label: 'Amistad' }, { value: 'enemy', label: 'Enemistad' }, { value: 'ally', label: 'Alianza' }, { value: 'other', label: 'Otra relación' }];
  private readonly destroyed = new Subject<void>();
  private detailRequest = 0;
  private catalogueRequest = 0;

  constructor(private readonly service: CharacterMapsService, private readonly route: ActivatedRoute, private readonly router: Router) {}
  ngOnInit(): void {
    this.loadCatalogue();
    this.route.paramMap.pipe(takeUntil(this.destroyed)).subscribe(params => {
      const id = params.get('bookId');
      if (id) this.loadDetail(id);
      else { this.detail = null; this.dirty = false; }
    });
  }
  ngOnDestroy(): void { this.destroyed.next(); this.destroyed.complete(); }
  @HostListener('document:keydown.escape') closeDialog(): void { this.queueAllOpen = false; this.pendingBook = null; this.historyOpen = false; }
  emptyPayload(): MapPayload { return { characters: [], relationships: [], merges: [] }; }
  evidence(): MapEvidence { return { chapter_id: this.detail?.chapters[0]?.id ?? '', quote: '' }; }
  get selectedCharacter(): MapCharacter | null { return this.payload.characters.find(character => character.key === this.selectedKey) ?? null; }
  get totalPages(): number { return Math.max(1, Math.ceil((this.catalogue?.count ?? 0) / this.pageSize)); }
  get canPublish(): boolean { return !!this.detail?.revision && this.detail.revision.status === 'approved'; }
  get maxPreviewWord(): number { return Math.max(-1, (this.detail?.chapters[this.previewChapter]?.word_count ?? 0) - 1); }

  loadCatalogue(): void {
    const request = ++this.catalogueRequest;
    this.loading = true;
    this.service.catalogue(this.query, this.status, this.page).pipe(takeUntil(this.destroyed)).subscribe({
      next: data => { if (request === this.catalogueRequest) { this.catalogue = data; this.loading = false; } },
      error: error => { if (request === this.catalogueRequest) { this.loading = false; this.showError(error); } }
    });
  }
  applyFilters(): void { this.page = 1; this.loadCatalogue(); }
  changePage(delta: number): void { this.page = Math.max(1, Math.min(this.totalPages, this.page + delta)); this.loadCatalogue(); }
  chooseBook(book: MapBookRow): void {
    if (book.book_id === this.detail?.book.id) return;
    if (this.dirty) { this.pendingBook = book; return; }
    this.navigateBook(book);
  }
  navigateBook(book: MapBookRow): void { this.pendingBook = null; void this.router.navigate(['/dashboard/character-maps', book.book_id]); }
  loadDetail(bookId: string): void {
    const request = ++this.detailRequest;
    this.loadingDetail = true; this.errors = []; this.previewData = null; this.previewError = '';
    this.service.detail(bookId).pipe(takeUntil(this.destroyed)).subscribe({
      next: data => {
        if (request !== this.detailRequest) return;
        this.detail = data;
        this.payload = this.normalizePayload(data.revision?.payload);
        this.errors = (data.revision?.errors ?? []).map(error => this.errorText(error));
        if (!this.payload.characters.some(character => character.key === this.selectedKey)) this.selectedKey = this.payload.characters[0]?.key ?? '';
        this.noCharacters = !!this.payload.no_characters_reason && this.payload.characters.length === 0;
        this.loadingDetail = false; this.dirty = false; this.reviewed = false;
        this.previewChapter = Math.min(this.previewChapter, Math.max(0, data.chapters.length - 1));
        this.previewWord = Math.min(this.previewWord, this.maxPreviewWord);
      },
      error: error => { if (request === this.detailRequest) { this.detail = null; this.loadingDetail = false; this.showError(error); } }
    });
  }
  private normalizePayload(raw?: MapPayload): MapPayload {
    const payload: MapPayload = JSON.parse(JSON.stringify(raw ?? this.emptyPayload()));
    payload.characters = Array.isArray(payload.characters) ? payload.characters : [];
    payload.relationships = Array.isArray(payload.relationships) ? payload.relationships : [];
    payload.merges = Array.isArray(payload.merges) ? payload.merges : [];
    for (const character of payload.characters) {
      character.evidence ??= this.evidence(); character.facts ??= []; character.names ??= []; character.roles ??= [];
      for (const fact of character.facts) fact.evidence ??= this.evidence();
      for (const name of character.names) name.evidence ??= this.evidence();
      for (const role of character.roles) role.evidence ??= this.evidence();
      if (character.role) character.role_evidence ??= this.evidence();
      if (character.portrait_avatar_id) character.portrait_evidence ??= this.evidence();
    }
    for (const relationship of payload.relationships) relationship.evidence ??= this.evidence();
    for (const merge of payload.merges) merge.evidence ??= this.evidence();
    return payload;
  }
  changed(): void { this.dirty = true; this.reviewed = false; this.previewData = null; this.message = ''; }
  key(prefix: string): string { return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`; }
  addCharacter(): void {
    const character: MapCharacter = { key: this.key('character'), name: '', evidence: this.evidence(), facts: [], names: [], roles: [] };
    this.payload.characters.push(character); this.selectedKey = character.key; this.noCharacters = false; delete this.payload.no_characters_reason; this.changed();
  }
  removeCharacter(character: MapCharacter): void {
    this.payload.characters = this.payload.characters.filter(item => item !== character);
    this.payload.relationships = this.payload.relationships.filter(item => item.source !== character.key && item.target !== character.key);
    this.payload.merges = this.payload.merges.filter(item => item.source !== character.key && item.target !== character.key);
    this.selectedKey = this.payload.characters[0]?.key ?? ''; this.changed();
  }
  noCharactersChanged(): void { if (!this.noCharacters) delete this.payload.no_characters_reason; this.changed(); }
  addFact(character: MapCharacter): void { character.facts.push({ key: this.key('fact'), text: '', evidence: this.evidence() }); this.changed(); }
  addName(character: MapCharacter): void { (character.names ??= []).push({ name: '', evidence: this.evidence() }); this.changed(); }
  addRole(character: MapCharacter): void { (character.roles ??= []).push({ role: 'supporting', evidence: this.evidence() }); this.changed(); }
  setRole(character: MapCharacter): void { if (character.role) character.role_evidence ??= this.evidence(); else delete character.role_evidence; this.changed(); }
  setPortrait(character: MapCharacter): void {
    if (character.portrait_avatar_id) character.portrait_evidence ??= this.evidence();
    else { delete character.portrait_avatar_id; delete character.portrait_evidence; }
    this.changed();
  }
  addRelationship(): void {
    this.payload.relationships.push({ key: this.key('relationship'), source: this.payload.characters[0]?.key ?? '', target: this.payload.characters[1]?.key ?? '', kind: 'other', label: '', evidence: this.evidence() }); this.changed();
  }
  addMerge(): void { this.payload.merges.push({ source: this.payload.characters[0]?.key ?? '', target: this.payload.characters[1]?.key ?? '', evidence: this.evidence() }); this.changed(); }
  setUntil(item: { until_evidence?: MapEvidence }, enabled: boolean): void { if (enabled) item.until_evidence = this.evidence(); else delete item.until_evidence; this.changed(); }
  characterName(key: string): string { return this.payload.characters.find(character => character.key === key)?.name || 'Personaje sin nombre'; }
  portraitUrl(avatarId?: string): string { return this.detail?.avatars.find(avatar => avatar.id === avatarId)?.portrait_url ?? ''; }

  save(): void {
    if (!this.detail) return;
    this.run(this.service.save(this.detail.book.id, this.detail.revision?.id ?? null, this.payload), 'Borrador guardado. Revisa sus evidencias antes de aprobar.');
  }
  generateCurrent(): void { if (this.detail) this.run(this.service.generate([this.detail.book.id]), 'Libro añadido a la cola de generación.'); }
  generateAll(): void { this.queueAllOpen = false; this.run(this.service.generate(), 'Catálogo añadido a la cola. Los trabajos respetarán el presupuesto disponible.'); }
  approve(): void {
    if (!this.detail?.revision || this.dirty || !this.reviewed) return;
    this.run(this.service.approve(this.detail.book.id, this.detail.revision.id, this.noCharacters, this.payload.no_characters_reason ?? ''), 'Revisión aprobada. Ya puedes publicarla.');
  }
  publish(): void {
    if (!this.detail?.revision || this.dirty || !this.canPublish) return;
    this.run(this.service.publish(this.detail.book.id, this.detail.revision.id), 'Mapa publicado para los lectores.');
  }
  private run(operation: Observable<unknown>, message: string): void {
    this.busy = true; this.message = ''; this.errors = [];
    const bookId = this.detail?.book.id;
    operation.pipe(takeUntil(this.destroyed)).subscribe({
      next: () => { this.busy = false; this.message = message; this.loadCatalogue(); if (bookId) this.loadDetail(bookId); },
      error: error => { this.busy = false; this.showError(error); }
    });
  }
  showPreview(): void {
    if (!this.detail?.revision || this.dirty) return;
    this.previewLoading = true; this.previewError = ''; this.editorTab = 'preview';
    this.previewWord = Math.min(Math.max(-1, this.previewWord), this.maxPreviewWord);
    const ordinal = this.detail.chapters[this.previewChapter]?.ordinal ?? this.previewChapter;
    this.service.preview(this.detail.book.id, this.detail.revision.id, ordinal, this.previewWord).pipe(takeUntil(this.destroyed)).subscribe({
      next: data => { this.previewData = data; this.previewLoading = false; },
      error: error => { this.previewLoading = false; this.previewError = this.errorText(error.error?.error ?? 'No se pudo cargar la vista previa. Revisa las evidencias.'); this.showError(error); }
    });
  }
  previewChapterChanged(): void { this.previewWord = 0; this.previewData = null; }
  showHistory(): void {
    if (!this.detail) return;
    this.historyOpen = true; this.historyLoading = true;
    this.service.history(this.detail.book.id).pipe(takeUntil(this.destroyed)).subscribe({
      next: history => { this.history = history; this.historyLoading = false; },
      error: error => { this.historyLoading = false; this.showError(error); }
    });
  }
  restore(revision: MapRevision): void {
    if (!this.detail || this.dirty) return;
    this.historyOpen = false;
    this.run(this.service.restore(this.detail.book.id, revision.id), 'Revisión recuperada.');
  }
  statusLabel(status: string): string {
    return this.statuses.find(item => item.value === status)?.label ?? ({ approved: 'Aprobado', approved_no_characters: 'Sin personajes, aprobado', draft: 'En revisión', queued: 'En cola', review: 'En revisión' } as Record<string, string>)[status] ?? status;
  }
  errorText(error: unknown): string { return typeof error === 'string' ? error : JSON.stringify(error); }
  private showError(error: HttpErrorResponse): void {
    const body = error.error;
    this.errors = Array.isArray(body?.errors) ? body.errors.map((item: unknown) => this.errorText(item)) : [this.errorText(body?.error ?? body?.detail ?? 'No se pudo completar la acción. Vuelve a intentarlo.')];
  }
}
