import { Component, DestroyRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Subject, catchError, forkJoin, of, startWith, switchMap } from 'rxjs';
import { ApiService } from '../../core/services/api.service';
import { CharacterMapService } from '../../core/services/character-map.service';
import { CharacterMapComponent } from '../../library/reader/character-map/character-map.component';
import { CharacterMapData } from '../../library/reader/character-map/character-map.models';

@Component({
  selector: 'app-character-map-page',
  standalone: true,
  imports: [CommonModule, RouterModule, CharacterMapComponent],
  templateUrl: './character-map-page.component.html',
  styleUrls: ['./character-map-page.component.css'],
})
export class CharacterMapPageComponent {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  private characterMapService = inject(CharacterMapService);
  private destroyRef = inject(DestroyRef);
  private reloadRequests = new Subject<void>();
  inventoryId = '';
  title = '';
  data: CharacterMapData | null = null;
  loading = true;
  error = '';

  constructor() {
    this.route.paramMap.pipe(
      switchMap(params => {
        this.inventoryId = params.get('id') || '';
        this.title = '';
        return this.reloadRequests.pipe(
          startWith(undefined),
          switchMap(() => {
            this.data = null;
            this.loading = true;
            this.error = '';
            return this.request();
          }),
        );
      }),
      takeUntilDestroyed(this.destroyRef),
    ).subscribe(result => this.receive(result));
  }

  reload(): void {
    this.reloadRequests.next();
  }

  private request() {
    return forkJoin({
      inventory: this.api.get<{ book_title: string }>(`library/inventory/${encodeURIComponent(this.inventoryId)}/`),
      map: this.characterMapService.get(this.inventoryId),
    }).pipe(catchError(() => of(null)));
  }

  private receive(result: { inventory: { book_title: string }; map: CharacterMapData } | null): void {
    this.loading = false;
    if (!result) {
      this.error = 'No se pudo abrir el mapa. Revisa tu conexión y confirma que el libro está en tu biblioteca.';
      return;
    }
    this.title = result.inventory.book_title;
    this.data = result.map;
  }
}
