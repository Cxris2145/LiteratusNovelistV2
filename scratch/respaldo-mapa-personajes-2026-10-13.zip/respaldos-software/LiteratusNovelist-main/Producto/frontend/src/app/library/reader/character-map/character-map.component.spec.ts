import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CharacterMapComponent } from './character-map.component';
import { CharacterMapData, buildCharacterGraph } from './character-map.models';

describe('Mapa de personajes sin adelantos', () => {
  let fixture: ComponentFixture<CharacterMapComponent>;
  const revealedData = (): CharacterMapData => ({
    available: true,
    position: { chapter: 0, word: 42 },
    characters: [
      { id: 'ana', name: 'Ana', portrait_url: null, role: null, facts: [{ id: 'first', text: 'Vive en el pueblo.' }] },
      { id: 'bruno', name: 'Bruno', portrait_url: null, role: 'supporting', facts: [] },
    ],
    relationships: [
      { id: 'friends', source_id: 'ana', target_id: 'bruno', kind: 'friend', label: 'Amigos' },
    ],
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({ imports: [CharacterMapComponent] }).compileComponents();
    fixture = TestBed.createComponent(CharacterMapComponent);
    fixture.componentInstance.view = 'graph';
  });

  function setData(data: CharacterMapData): void {
    fixture.componentRef.setInput('data', data);
    fixture.detectChanges();
  }

  it('no dibuja vínculos con personajes ausentes ni infiere un papel', () => {
    const data = revealedData();
    data.relationships.push({ id: 'future', source_id: 'ana', target_id: 'unrevealed', kind: 'enemy', label: 'Revelación futura' });
    setData(data);
    expect(fixture.componentInstance.graph.edges.length).toBe(1);
    expect(fixture.nativeElement.textContent).not.toContain('Revelación futura');
    expect(fixture.nativeElement.querySelector('.character-node[aria-label="Ana, Personaje"] .role-label')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('capítulo 1');
  });

  it('actualiza la ficha y elimina información anterior al recibir menos progreso', () => {
    setData(revealedData());
    fixture.componentInstance.selectCharacter('bruno');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.character-detail h3').textContent).toContain('Bruno');
    const earlierData = revealedData();
    earlierData.characters = [earlierData.characters[0]];
    earlierData.characters[0].facts = [];
    earlierData.relationships = [];
    setData(earlierData);
    expect(fixture.componentInstance.selectedId).toBe('ana');
    expect(fixture.nativeElement.textContent).not.toContain('Bruno');
    expect(fixture.nativeElement.textContent).not.toContain('Vive en el pueblo.');
    expect(fixture.nativeElement.textContent).not.toContain('Amigos');
  });

  it('permite recorrer personajes y vínculos en la vista lista', () => {
    setData(revealedData());
    fixture.componentInstance.setView('list');
    fixture.detectChanges();
    const rows = fixture.nativeElement.querySelectorAll('.character-list-row') as NodeListOf<HTMLButtonElement>;
    expect(rows.length).toBe(2);
    rows[1].click();
    fixture.detectChanges();
    expect(fixture.componentInstance.selectedId).toBe('bruno');
    expect(fixture.nativeElement.querySelector('.related-character').textContent).toContain('Ana');
    expect(rows[1].getAttribute('aria-pressed')).toBe('true');
  });

  it('sustituye una fotografía rota por las iniciales', () => {
    const data = revealedData();
    data.characters[0].portrait_url = 'https://example.invalid/portrait.jpg';
    setData(data);
    const image = fixture.nativeElement.querySelector('.character-node img') as HTMLImageElement;
    image.dispatchEvent(new Event('error'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.character-node img')).toBeNull();
    expect(fixture.nativeElement.querySelector('.character-node .initials').textContent).toBe('A');
  });

  it('oculta el mapa anterior mientras carga y permite reintentar un fallo', () => {
    setData(revealedData());
    fixture.componentRef.setInput('loading', true);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('.character-detail')).toBeNull();
    fixture.componentRef.setInput('loading', false);
    fixture.componentRef.setInput('error', 'Comprueba tu conexión.');
    fixture.detectChanges();
    const retry = spyOn(fixture.componentInstance.retry, 'emit');
    fixture.nativeElement.querySelector('.map-button').click();
    expect(retry).toHaveBeenCalled();
    expect(fixture.nativeElement.querySelector('.character-detail')).toBeNull();
  });

  it('mantiene el mismo diagrama si cambia el orden de una respuesta', () => {
    const data = revealedData();
    const graph = buildCharacterGraph(data);
    const reversed = buildCharacterGraph({ ...data, characters: [...data.characters].reverse() });
    expect(reversed).toEqual(graph);
    expect(graph.nodes.every(node => Number.isFinite(node.x) && Number.isFinite(node.y))).toBeTrue();
  });

  it('separa los vínculos recíprocos para que sus etiquetas no se superpongan', () => {
    const data = revealedData();
    data.relationships.push({ id: 'reciprocal', source_id: 'bruno', target_id: 'ana', kind: 'ally', label: 'Protege a' });
    const graph = buildCharacterGraph(data);
    const first = graph.edges[0];
    const second = graph.edges[1];
    expect(Math.hypot(first.labelX - second.labelX, first.labelY - second.labelY)).toBeGreaterThanOrEqual(28);
  });

  it('busca nombres conocidos sin distinguir mayúsculas ni acentos y permite recuperar un filtro vacío', () => {
    const data = revealedData();
    data.characters[0].name = 'Ána';
    setData(data);
    fixture.componentInstance.setView('list');
    const search = fixture.nativeElement.querySelector('input[type="search"]') as HTMLInputElement;
    search.value = 'ana';
    search.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.character-list-row').length).toBe(1);
    expect(fixture.nativeElement.querySelector('.character-list-row').textContent).toContain('Ána');
    expect(fixture.nativeElement.querySelector('.character-detail').textContent).not.toContain('Bruno');
    search.value = 'Desconocido';
    search.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(fixture.componentInstance.selectedId).toBeNull();
    expect(fixture.nativeElement.querySelector('.character-detail')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('No hay coincidencias');
    fixture.nativeElement.querySelector('.filter-state .map-button').click();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('.character-list-row').length).toBe(2);
  });

  it('combina filtros por papel y vínculo usando únicamente personajes y tipos revelados', () => {
    const data = revealedData();
    data.characters.push({ id: 'clara', name: 'Clara', portrait_url: null, role: 'protagonist', facts: [] });
    data.relationships.push({ id: 'future', source_id: 'ana', target_id: 'unrevealed', kind: 'enemy', label: 'Secreto futuro' });
    setData(data);
    expect(fixture.componentInstance.relationshipKinds).toEqual(['friend']);
    expect(fixture.componentInstance.roles).not.toContain('antagonist');
    expect(fixture.nativeElement.textContent).not.toContain('Secreto futuro');
    expect(fixture.nativeElement.querySelector('option[value="enemy"]')).toBeNull();
    fixture.componentInstance.setKind('friend');
    expect(fixture.componentInstance.filteredCharacters.map(character => character.id)).toEqual(['ana', 'bruno']);
    fixture.componentInstance.setRole('supporting');
    fixture.detectChanges();
    expect(fixture.componentInstance.filteredCharacters.map(character => character.id)).toEqual(['bruno']);
    expect(fixture.componentInstance.graph.edges).toEqual([]);
    expect(fixture.nativeElement.querySelector('.character-detail h3').textContent).toContain('Bruno');
  });

  it('muestra solo vínculos del seleccionado y actualiza las líneas al cambiar la selección', () => {
    const data = revealedData();
    data.characters.push({ id: 'clara', name: 'Clara', portrait_url: null, role: null, facts: [] });
    data.relationships.push({ id: 'family', source_id: 'bruno', target_id: 'clara', kind: 'family', label: 'Hermanos' });
    setData(data);
    fixture.componentInstance.setSelectedLinksOnly(true);
    expect(fixture.componentInstance.graph.nodes.length).toBe(3);
    expect(fixture.componentInstance.graph.edges.map(edge => edge.relationship.id)).toEqual(['friends']);
    fixture.componentInstance.selectCharacter('clara');
    fixture.detectChanges();
    expect(fixture.componentInstance.graph.edges.map(edge => edge.relationship.id)).toEqual(['family']);
    expect(fixture.componentInstance.selectedRelationships.map(relationship => relationship.id)).toEqual(['family']);
    expect(fixture.nativeElement.querySelector('.character-detail h3').textContent).toContain('Clara');
  });

  it('retira opciones y selección de una revelación futura al retroceder', () => {
    const data = revealedData();
    data.characters[1].role = 'antagonist';
    data.relationships[0].kind = 'enemy';
    setData(data);
    fixture.componentInstance.setRole('antagonist');
    fixture.componentInstance.setKind('enemy');
    fixture.componentInstance.setSelectedLinksOnly(true);
    const earlier = revealedData();
    earlier.characters = [earlier.characters[0]];
    earlier.relationships = [];
    setData(earlier);
    expect(fixture.componentInstance.roleFilter).toBe('');
    expect(fixture.componentInstance.kindFilter).toBe('');
    expect(fixture.componentInstance.selectedId).toBe('ana');
    expect(fixture.nativeElement.textContent).not.toContain('Bruno');
    expect(fixture.nativeElement.querySelector('option[value="antagonist"]')).toBeNull();
    expect(fixture.nativeElement.querySelector('option[value="enemy"]')).toBeNull();
  });

  it('empieza con lista para más de 25 personajes y conserva la vista elegida al cambiar progreso', () => {
    spyOn(window, 'matchMedia').and.returnValue({ matches: false } as MediaQueryList);
    const data = revealedData();
    data.characters = Array.from({ length: 26 }, (_, index) => ({
      id: `person-${index}`, name: `Persona ${index}`, portrait_url: null, role: null, facts: [],
    }));
    data.relationships = [];
    setData(data);
    expect(fixture.componentInstance.view).toBe('list');
    fixture.componentInstance.setView('graph');
    setData({ ...data, position: { chapter: 1, word: 99 } });
    expect(fixture.componentInstance.view).toBe('graph');
  });

  it('empieza con lista en móvil y reinicia filtros y vista cuando se abre otro libro', () => {
    spyOn(window, 'matchMedia').and.returnValue({ matches: true } as MediaQueryList);
    fixture.componentRef.setInput('mapKey', 'first-book');
    setData(revealedData());
    expect(fixture.componentInstance.view).toBe('list');
    fixture.componentInstance.setView('graph');
    fixture.componentInstance.setSearch('Ana');
    fixture.componentInstance.setSelectedLinksOnly(true);
    fixture.componentRef.setInput('mapKey', 'second-book');
    setData(revealedData());
    expect(fixture.componentInstance.view).toBe('list');
    expect(fixture.componentInstance.hasFilters).toBeFalse();
    expect(fixture.componentInstance.filteredCharacters.length).toBe(2);
  });
});
