import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { CharacterMapData, CharacterRelationshipKind, CharacterRole } from '../../library/reader/character-map/character-map.models';

export interface MapEvidence { chapter_id: string; quote: string; }
export interface MapFact { key: string; text: string; evidence: MapEvidence; until_evidence?: MapEvidence; }
export interface MapName { name: string; evidence: MapEvidence; }
export interface MapRole { role: CharacterRole; evidence: MapEvidence; until_evidence?: MapEvidence; }
export interface MapCharacter {
  key: string; name: string; evidence: MapEvidence; facts: MapFact[];
  portrait_avatar_id?: string; portrait_evidence?: MapEvidence;
  role?: CharacterRole; role_evidence?: MapEvidence; names?: MapName[]; roles?: MapRole[];
}
export interface MapRelationship {
  key: string; source: string; target: string; kind: CharacterRelationshipKind;
  label: string; evidence: MapEvidence; until_evidence?: MapEvidence;
}
export interface MapMerge { source: string; target: string; evidence: MapEvidence; }
export interface MapPayload {
  characters: MapCharacter[]; relationships: MapRelationship[]; merges: MapMerge[];
  no_characters_reason?: string;
}
export interface MapChapter { id: string; title: string; order: number; ordinal?: number; word_count: number; content_text?: string; }
export interface MapRevision {
  id: string; status: string; source_hash: string; payload: MapPayload; errors: unknown[];
  reviewed_at?: string | null; created_at?: string; published_at?: string | null;
}
export interface MapBookRow {
  book_id: string; title: string; slug: string; status: string; revision_id: string | null;
  published_revision_id: string | null; chapters_count: number; word_count: number; error?: string;
}
export interface MapBudget {
  limit_usd: number | string; spent_usd: number | string; reserved_usd: number | string; remaining_usd: number | string; model: string;
  pricing_verified: boolean; pricing_source?: string; input_usd_per_million: number | string; output_usd_per_million: number | string;
}
export interface MapCoverage {
  total: number; pending: number; review: number; published: number; no_characters: number;
  stale: number; failed: number; budget_paused: number; approved?: number; generating?: number;
}
export interface MapCatalogue { count: number; results: MapBookRow[]; budget: MapBudget; coverage: MapCoverage; }
export interface MapBookDetail {
  book: { id: string; title: string; slug: string }; chapters: MapChapter[];
  avatars: { id: string; name: string; portrait_url: string }[];
  revision: MapRevision | null; published_revision_id: string | null;
}

@Injectable({ providedIn: 'root' })
export class CharacterMapsService {
  private readonly url = `${environment.apiUrl}dashboard/character-maps`;
  constructor(private readonly http: HttpClient) {}

  catalogue(q = '', status = '', page = 1): Observable<MapCatalogue> {
    return this.http.get<MapCatalogue>(`${this.url}/`, { params: new HttpParams().set('q', q).set('status', status).set('page', page) });
  }
  detail(bookId: string): Observable<MapBookDetail> { return this.http.get<MapBookDetail>(`${this.url}/${bookId}/`); }
  source(bookId: string, chapterId: string): Observable<{ chapter_id: string; title: string; text: string; words: string[] }> {
    return this.http.get<{ chapter_id: string; title: string; text: string; words: string[] }>(`${this.url}/${bookId}/source/`, { params: { chapter_id: chapterId } });
  }
  generate(bookIds?: string[]): Observable<unknown> {
    return this.http.post(`${this.url}/generate/`, bookIds ? { book_ids: bookIds } : { all: true });
  }
  save(bookId: string, revisionId: string | null, payload: MapPayload): Observable<unknown> {
    return this.http.patch(`${this.url}/${bookId}/`, { revision_id: revisionId, payload });
  }
  preview(bookId: string, revisionId: string, chapter: number, word: number): Observable<CharacterMapData> {
    return this.http.post<CharacterMapData>(`${this.url}/${bookId}/preview/`, { revision_id: revisionId, chapter, word });
  }
  approve(bookId: string, revisionId: string, noCharacters: boolean, reason: string): Observable<unknown> {
    return this.http.post(`${this.url}/${bookId}/approve/`, { revision_id: revisionId, no_characters: noCharacters, reason });
  }
  publish(bookId: string, revisionId: string): Observable<unknown> {
    return this.http.post(`${this.url}/${bookId}/publish/`, { revision_id: revisionId });
  }
  restore(bookId: string, revisionId: string): Observable<unknown> {
    return this.http.post(`${this.url}/${bookId}/restore/`, { revision_id: revisionId });
  }
  history(bookId: string): Observable<MapRevision[]> { return this.http.get<MapRevision[]>(`${this.url}/${bookId}/history/`); }
}
