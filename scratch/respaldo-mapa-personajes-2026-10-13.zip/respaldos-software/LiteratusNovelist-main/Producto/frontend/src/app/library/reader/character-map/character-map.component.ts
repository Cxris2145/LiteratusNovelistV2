import { CommonModule } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import {
  BookCharacter, CharacterGraph, CharacterMapData, CharacterRelationship,
  CharacterRole, CharacterRelationshipKind, buildCharacterGraph, relationshipKindLabel,
} from './character-map.models';

@Component({
  selector: 'app-character-map',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './character-map.component.html',
  styleUrl: './character-map.component.css',
})
export class CharacterMapComponent implements OnChanges {
  @Input() data: CharacterMapData | null | undefined = null;
  @Input() loading = false;
  @Input() error = '';
  @Input() showHeading = true;
  /** The inventory ID lets a reused page reset controls when a different book opens. */
  @Input() mapKey = '';
  @Output() retry = new EventEmitter<void>();
  @ViewChild('graphViewport') graphViewport?: ElementRef<HTMLElement>;

  graph: CharacterGraph = buildCharacterGraph(null);
  filteredCharacters: BookCharacter[] = [];
  selectedId: string | null = null;
  view: 'graph' | 'list' = this.isMobile() ? 'list' : 'graph';
  searchTerm = '';
  roleFilter: CharacterRole | 'unknown' | '' = '';
  kindFilter: CharacterRelationshipKind | '' = '';
  selectedLinksOnly = false;
  private viewChosen = false;
  zoom = 1;
  brokenPortraits = new Set<string>();
  readonly kindLabel = relationshipKindLabel;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['mapKey']) {
      this.searchTerm = '';
      this.roleFilter = '';
      this.kindFilter = '';
      this.selectedLinksOnly = false;
      this.selectedId = null;
      this.brokenPortraits.clear();
      this.viewChosen = false;
    }
    if (!this.viewChosen) this.view = this.isMobile() || (this.data?.characters.length ?? 0) > 25 ? 'list' : 'graph';
    this.applyFilters();
    // Never retain a detail from an earlier response after progress changes.
    const visibleIds = new Set(this.data?.characters.map(character => character.id) ?? []);
    this.brokenPortraits = new Set([...this.brokenPortraits].filter(id => visibleIds.has(id)));
  }

  get selectedCharacter(): BookCharacter | null {
    return this.filteredCharacters.find(character => character.id === this.selectedId) ?? null;
  }

  get roles(): (CharacterRole | 'unknown')[] {
    const characters = this.data?.characters ?? [];
    return (['protagonist', 'antagonist', 'supporting', 'unknown'] as const)
      .filter(role => characters.some(character => role === 'unknown' ? character.role === null : character.role === role));
  }

  get relationshipKinds(): CharacterRelationshipKind[] {
    const relationships = this.revealedRelationships();
    return (['family', 'friend', 'enemy', 'ally', 'other'] as const)
      .filter(kind => relationships.some(relationship => relationship.kind === kind));
  }

  get hasFilters(): boolean {
    return !!this.searchTerm.trim() || !!this.roleFilter || !!this.kindFilter || this.selectedLinksOnly;
  }

  setSearch(value: string): void {
    this.searchTerm = value;
    this.applyFilters();
  }

  setRole(value: string): void {
    this.roleFilter = this.roles.find(role => role === value) ?? '';
    this.applyFilters();
  }

  setKind(value: string): void {
    this.kindFilter = this.relationshipKinds.find(kind => kind === value) ?? '';
    this.applyFilters();
  }

  setSelectedLinksOnly(value: boolean): void {
    this.selectedLinksOnly = value;
    this.applyFilters();
  }

  clearFilters(): void {
    this.searchTerm = '';
    this.roleFilter = '';
    this.kindFilter = '';
    this.selectedLinksOnly = false;
    this.applyFilters();
  }

  private revealedRelationships(): CharacterRelationship[] {
    const ids = new Set(this.data?.characters.map(character => character.id) ?? []);
    return (this.data?.relationships ?? []).filter(relationship =>
      ids.has(relationship.source_id) && ids.has(relationship.target_id) && relationship.source_id !== relationship.target_id);
  }

  private applyFilters(): void {
    // Every filter is derived from the current public snapshot, including its options.
    if (this.roleFilter && !this.roles.includes(this.roleFilter)) this.roleFilter = '';
    if (this.kindFilter && !this.relationshipKinds.includes(this.kindFilter)) this.kindFilter = '';
    let relationships = this.revealedRelationships().filter(relationship => !this.kindFilter || relationship.kind === this.kindFilter);
    const linkedIds = new Set(relationships.flatMap(relationship => [relationship.source_id, relationship.target_id]));
    const query = this.normalize(this.searchTerm.trim());
    this.filteredCharacters = (this.data?.characters ?? []).filter(character =>
      (!query || this.normalize(character.name).includes(query)) &&
      (!this.roleFilter || (this.roleFilter === 'unknown' ? character.role === null : character.role === this.roleFilter)) &&
      (!this.kindFilter || linkedIds.has(character.id)));
    if (!this.filteredCharacters.some(character => character.id === this.selectedId)) {
      this.selectedId = this.filteredCharacters[0]?.id ?? null;
    }
    if (this.selectedLinksOnly) relationships = relationships.filter(relationship => this.isSelectedEdge(relationship));
    this.graph = buildCharacterGraph(this.data ? { ...this.data, characters: this.filteredCharacters, relationships } : null);
    queueMicrotask(() => this.fitGraph());
  }

  private normalize(value: string): string {
    return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('es');
  }

  private isMobile(): boolean {
    return typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia('(max-width: 600px)').matches;
  }

  get selectedRelationships(): CharacterRelationship[] {
    return this.graph.edges.map(edge => edge.relationship).filter(relationship =>
      relationship.source_id === this.selectedId || relationship.target_id === this.selectedId);
  }

  selectCharacter(id: string): void {
    if (this.filteredCharacters.some(character => character.id === id)) {
      this.selectedId = id;
      if (this.selectedLinksOnly) this.applyFilters();
    }
  }

  otherCharacter(relationship: CharacterRelationship): BookCharacter | null {
    const id = relationship.source_id === this.selectedId ? relationship.target_id : relationship.source_id;
    return this.characterById(id);
  }

  characterById(id: string): BookCharacter | null {
    return this.filteredCharacters.find(character => character.id === id) ?? null;
  }

  roleLabel(role: CharacterRole | null): string {
    return role ? ({ protagonist: 'Protagonista', antagonist: 'Antagonista', supporting: 'Secundario' })[role] : 'Personaje';
  }

  initials(name: string): string {
    return name.trim().split(/\s+/).slice(0, 2).map(part => part[0] ?? '').join('').toLocaleUpperCase('es');
  }

  portraitFailed(id: string): void {
    this.brokenPortraits.add(id);
  }

  isSelectedEdge(relationship: CharacterRelationship): boolean {
    return relationship.source_id === this.selectedId || relationship.target_id === this.selectedId;
  }

  setView(view: 'graph' | 'list'): void {
    this.viewChosen = true;
    this.view = view;
    if (view === 'graph') queueMicrotask(() => this.fitGraph());
  }

  changeZoom(amount: number): void {
    this.zoom = Math.max(0.4, Math.min(1.6, Math.round((this.zoom + amount) * 100) / 100));
  }

  fitGraph(): void {
    const viewport = this.graphViewport?.nativeElement;
    if (!viewport) return;
    this.zoom = Math.max(0.4, Math.min(1, (viewport.clientWidth - 12) / this.graph.width, (viewport.clientHeight - 12) / this.graph.height));
    viewport.scrollTo({ left: 0, top: 0, behavior: 'auto' });
  }

  trackCharacter = (_: number, character: BookCharacter) => character.id;
  trackNode = (_: number, node: CharacterGraph['nodes'][number]) => node.character.id;
  trackEdge = (_: number, edge: CharacterGraph['edges'][number]) => edge.relationship.id;
  trackRelationship = (_: number, relationship: CharacterRelationship) => relationship.id;
  trackFact = (_: number, fact: BookCharacter['facts'][number]) => fact.id;
}
