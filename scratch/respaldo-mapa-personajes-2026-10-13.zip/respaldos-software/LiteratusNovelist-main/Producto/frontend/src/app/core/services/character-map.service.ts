import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { ApiService } from './api.service';
import { CharacterMapData } from '../../library/reader/character-map/character-map.models';

@Injectable({ providedIn: 'root' })
export class CharacterMapService {
  private api = inject(ApiService);

  /** Always revalidate the owner's saved position; never cache another reading position. */
  get(inventoryId: string): Observable<CharacterMapData> {
    return this.api.get<CharacterMapData>(`library/inventory/${encodeURIComponent(inventoryId)}/character-map/`, new HttpParams().set('ngsw-bypass', 'true'));
  }
}
