module.exports = function (config) {
  config.set({
    basePath: '../../../..',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [require('karma-jasmine'), require('karma-chrome-launcher'), require('@angular-devkit/build-angular/plugins/karma')],
    reporters: ['progress'], port: 9877, singleRun: true, restartOnFileChange: false,
    customLaunchers: { EditorialHeadless: { base: 'ChromeHeadless', flags: ['--remote-debugging-port=0', '--no-sandbox'] } },
    browsers: ['EditorialHeadless']
  });
};
