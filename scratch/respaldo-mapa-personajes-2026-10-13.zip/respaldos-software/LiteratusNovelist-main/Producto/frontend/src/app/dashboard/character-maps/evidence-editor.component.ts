import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CharacterMapsService, MapChapter, MapEvidence } from '../services/character-maps.service';

@Component({
  selector: 'app-map-evidence-editor',
  template: `
    <div class="evidence-editor">
      <label>{{ label }}
        <select [ngModel]="evidence.chapter_id" (ngModelChange)="changeChapter($event)">
          <option value="">Elegir capítulo</option>
          <option *ngFor="let chapter of chapters" [value]="chapter.id">{{ chapter.title || ('Capítulo ' + (chapter.order + 1)) }}</option>
        </select>
      </label>
      <label>Pasaje exacto del libro
        <textarea rows="3" [ngModel]="evidence.quote" (ngModelChange)="changeQuote($event)" placeholder="Copia las palabras que sostienen este dato."></textarea>
      </label>
      <div class="source-tools">
        <small>El dato se revela al terminar este pasaje.</small>
        <button type="button" (click)="viewSource()" [disabled]="!evidence.chapter_id || loading">{{ loading ? 'Cargando texto…' : (sourceOpen ? 'Ocultar capítulo' : 'Consultar capítulo') }}</button>
      </div>
      <p class="source-error" role="alert" *ngIf="error">{{ error }}</p>
      <div class="chapter-source" *ngIf="sourceOpen && source">
        <p class="match-note">{{ matches ? 'El pasaje aparece en el capítulo.' : 'El pasaje no coincide literalmente. Copia un fragmento de este texto.' }}</p>
        <p *ngIf="!matches">{{ source }}</p>
        <p *ngIf="matches">{{ sourceBefore }}<mark>{{ evidence.quote }}</mark>{{ sourceAfter }}</p>
      </div>
    </div>
  `,
  styles: [`
    :host { display: block; min-width: 0; }
    .evidence-editor { padding: 14px; background: var(--color-bg-secondary, #14263b); border-left: 3px solid var(--color-border, #33455f); }
    label { display: grid; gap: 5px; font-size: 12px; color: var(--color-text-secondary, #b8c3d3); margin-bottom: 10px; }
    select, textarea { box-sizing: border-box; width: 100%; padding: 9px 10px; border: 1px solid var(--color-border, #33455f); border-radius: 5px; background: var(--color-surface, #182a40); color: var(--color-text-primary, #e6edf6); font: inherit; font-size: 13px; }
    textarea { resize: vertical; line-height: 1.55; }
    .source-tools { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    small { font-size: 11px; color: var(--color-text-secondary, #b8c3d3); }
    button { background: transparent; color: var(--color-primary, #63b3ed); border: 0; font: inherit; font-size: 12px; text-decoration: underline; cursor: pointer; padding: 3px; }
    button:disabled { opacity: .5; cursor: default; }
    :is(select, textarea, button):focus-visible { outline: 2px solid var(--color-primary, #63b3ed); outline-offset: 2px; }
    .chapter-source { max-height: 310px; overflow: auto; margin-top: 12px; padding: 14px; background: var(--color-surface, #182a40); font: 14px/1.7 Georgia, serif; white-space: pre-wrap; user-select: text; }
    .chapter-source p { margin: 0 0 8px; }
    .match-note { font: 12px/1.5 'Fira Sans', sans-serif; color: var(--color-text-secondary, #b8c3d3); }
    mark { background: #fde68a; color: #172033; }
    .source-error { color: var(--color-error, #fda4af); font-size: 12px; }
  `]
})
export class EvidenceEditorComponent {
  @Input() evidence: MapEvidence = { chapter_id: '', quote: '' };
  @Input() chapters: MapChapter[] = [];
  @Input() bookId = '';
  @Input() label = 'Capítulo de la evidencia';
  @Output() evidenceChange = new EventEmitter<MapEvidence>();
  loading = false;
  sourceOpen = false;
  source = '';
  error = '';
  private request = 0;
  constructor(private readonly service: CharacterMapsService) {}
  get matches(): boolean { return !!this.evidence.quote.trim() && this.source.includes(this.evidence.quote); }
  get sourceBefore(): string { return this.source.slice(0, this.source.indexOf(this.evidence.quote)); }
  get sourceAfter(): string { return this.source.slice(this.source.indexOf(this.evidence.quote) + this.evidence.quote.length); }
  changeChapter(chapter_id: string): void {
    this.request++;
    this.source = ''; this.sourceOpen = false; this.loading = false; this.error = '';
    this.evidence = { ...this.evidence, chapter_id };
    this.evidenceChange.emit(this.evidence);
  }
  changeQuote(quote: string): void { this.evidence = { ...this.evidence, quote }; this.evidenceChange.emit(this.evidence); }
  viewSource(): void {
    if (this.sourceOpen) { this.sourceOpen = false; return; }
    this.sourceOpen = true;
    if (this.source) return;
    this.loading = true; this.error = '';
    const request = ++this.request;
    this.service.source(this.bookId, this.evidence.chapter_id).subscribe({
      next: (data) => { if (request === this.request) { this.source = data.text; this.loading = false; } },
      error: () => { if (request === this.request) { this.loading = false; this.error = 'No se pudo cargar el capítulo. Intenta consultarlo otra vez.'; this.sourceOpen = false; } }
    });
  }
}
