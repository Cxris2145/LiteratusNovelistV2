import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { A11yModule } from '@angular/cdk/a11y';
import { ActivatedRoute, convertToParamMap, Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { By } from '@angular/platform-browser';
import { CharacterMapsComponent } from './character-maps.component';
import { EvidenceEditorComponent } from './evidence-editor.component';
import { CharacterMapComponent } from '../../library/reader/character-map/character-map.component';
import { CharacterMapsService, MapBookDetail, MapCatalogue } from '../services/character-maps.service';

describe('Revisión editorial de mapas', () => {
  let fixture: ComponentFixture<CharacterMapsComponent>;
  let component: CharacterMapsComponent;
  let service: jasmine.SpyObj<CharacterMapsService>;
  let router: jasmine.SpyObj<Router>;
  let current: MapBookDetail;
  const book = (): MapBookDetail => ({
    book: { id: 'book-a', title: 'Una historia', slug: 'una-historia' },
    chapters: [{ id: 'chapter-a', title: 'Comienzo', order: 0, word_count: 25 }], avatars: [],
    published_revision_id: 'published-a',
    revision: { id: 'draft-a', status: 'review', source_hash: 'text-a', errors: [], reviewed_at: null,
      payload: { characters: [{ key: 'ana', name: 'Ana', evidence: { chapter_id: 'chapter-a', quote: 'Ana llegó' }, facts: [] }, { key: 'bruno', name: 'Bruno', evidence: { chapter_id: 'chapter-a', quote: 'Bruno salió' }, facts: [] }],
        relationships: [{ key: 'friendship', source: 'ana', target: 'bruno', kind: 'friend', label: 'Amigos', evidence: { chapter_id: 'chapter-a', quote: 'eran amigos' } }], merges: [] }
    }
  });
  const catalogue: MapCatalogue = {
    count: 1, results: [{ book_id: 'book-a', title: 'Una historia', slug: 'una-historia', status: 'review', revision_id: 'draft-a', published_revision_id: 'published-a', chapters_count: 1, word_count: 25 }],
    coverage: { total: 1, pending: 0, review: 1, published: 1, no_characters: 0, stale: 0, failed: 0, budget_paused: 2 },
    budget: { limit_usd: 100, spent_usd: 2.25, reserved_usd: 1.1, remaining_usd: 96.65, model: 'gemini-test', pricing_verified: true, input_usd_per_million: .3, output_usd_per_million: 2.5 }
  };
  beforeEach(async () => {
    current = book();
    service = jasmine.createSpyObj<CharacterMapsService>('CharacterMapsService', ['catalogue', 'detail', 'save', 'approve', 'publish', 'generate', 'preview', 'source', 'history', 'restore']);
    service.catalogue.and.returnValue(of(catalogue)); service.detail.and.callFake(() => of(JSON.parse(JSON.stringify(current))));
    service.save.and.returnValue(of({})); service.approve.and.returnValue(of({})); service.publish.and.returnValue(of({}));
    service.generate.and.returnValue(of({})); service.history.and.returnValue(of([]));
    router = jasmine.createSpyObj<Router>('Router', ['navigate']); router.navigate.and.returnValue(Promise.resolve(true));
    await TestBed.configureTestingModule({
      imports: [CommonModule, FormsModule, A11yModule, CharacterMapComponent], declarations: [CharacterMapsComponent, EvidenceEditorComponent],
      providers: [{ provide: CharacterMapsService, useValue: service }, { provide: Router, useValue: router }, { provide: ActivatedRoute, useValue: { paramMap: of(convertToParamMap({ bookId: 'book-a' })) } }]
    }).compileComponents();
    fixture = TestBed.createComponent(CharacterMapsComponent); component = fixture.componentInstance; fixture.detectChanges();
  });

  it('muestra consumo, reservas, disponible y trabajos detenidos sin ocultar el mapa publicado', () => {
    const text = fixture.nativeElement.textContent;
    expect(text).toContain('US$2.25'); expect(text).toContain('US$1.10'); expect(text).toContain('US$96.65');
    expect(text).toContain('2 trabajos pausados por presupuesto'); expect(text).toContain('Hay una revisión publicada');
  });

  it('exige guardar y revisar antes de aprobar; una corrección elimina la declaración anterior', () => {
    component.reviewed = true; component.changed(); component.approve();
    expect(component.reviewed).toBeFalse(); expect(service.approve).not.toHaveBeenCalled();
    component.save(); expect(service.save).toHaveBeenCalledWith('book-a', 'draft-a', component.payload);
    component.reviewed = true; component.approve();
    expect(service.approve).toHaveBeenCalledWith('book-a', 'draft-a', false, '');
  });

  it('mantiene la publicación anterior al editar y bloquea publicar hasta tener aprobación', () => {
    expect(component.canPublish).toBeFalse(); expect(component.detail?.published_revision_id).toBe('published-a');
    current.revision!.status = 'approved'; component.loadDetail('book-a'); expect(component.canPublish).toBeTrue();
    component.changed(); component.publish(); expect(service.publish).not.toHaveBeenCalled();
    expect(component.detail?.published_revision_id).toBe('published-a');
    current.revision!.status = 'review'; component.save(); expect(component.canPublish).toBeFalse();
  });

  it('conserva correcciones cuando la validación rechaza una aprobación', () => {
    service.approve.and.returnValue(throwError(() => new HttpErrorResponse({ status: 400, error: { errors: ['La cita aparece más de una vez.'] } })));
    component.reviewed = true; component.approve();
    expect(component.errors).toEqual(['La cita aparece más de una vez.']); expect(component.payload.characters[0].name).toBe('Ana'); expect(component.busy).toBeFalse();
  });

  it('la vista previa pide una posición editorial y exige guardar antes de consultarla', () => {
    service.preview.and.returnValue(of({ available: true, characters: [], relationships: [], position: { chapter: 0, word: 24 } }));
    component.previewWord = 90; component.showPreview();
    expect(service.preview).toHaveBeenCalledWith('book-a', 'draft-a', 0, 24);
    component.changed(); service.preview.calls.reset(); component.showPreview(); expect(service.preview).not.toHaveBeenCalled();
  });

  it('elimina vínculos y uniones que apuntan a un personaje eliminado', () => {
    component.payload.merges.push({ source: 'ana', target: 'bruno', evidence: { chapter_id: 'chapter-a', quote: 'la misma persona' } });
    component.removeCharacter(component.payload.characters[0]);
    expect(component.payload.characters.length).toBe(1); expect(component.payload.relationships).toEqual([]); expect(component.payload.merges).toEqual([]);
  });

  it('protege cambios pendientes al seleccionar otro libro', () => {
    component.changed(); component.chooseBook({ ...catalogue.results[0], book_id: 'book-b', title: 'Otro libro' });
    expect(component.pendingBook?.book_id).toBe('book-b'); expect(router.navigate).not.toHaveBeenCalled();
    component.closeDialog(); expect(component.pendingBook).toBeNull(); expect(component.dirty).toBeTrue();
  });

  it('elimina el motivo sin personajes al añadir uno y permite aprobar la ausencia de mapa', () => {
    current.revision!.payload = { characters: [], relationships: [], merges: [], no_characters_reason: 'Tratado sin figuras identificables.' };
    component.loadDetail('book-a'); component.reviewed = true; component.approve();
    expect(service.approve).toHaveBeenCalledWith('book-a', 'draft-a', true, 'Tratado sin figuras identificables.');
    component.addCharacter(); expect(component.noCharacters).toBeFalse(); expect(component.payload.no_characters_reason).toBeUndefined();
  });

  it('consulta la fuente del capítulo junto a la evidencia sin cargarla por defecto', () => {
    expect(service.source).not.toHaveBeenCalled();
    service.source.and.returnValue(of({ chapter_id: 'chapter-a', title: 'Comienzo', text: 'Ana llegó al pueblo.', words: ['Ana', 'llegó', 'al', 'pueblo.'] }));
    const evidence = fixture.debugElement.query(By.directive(EvidenceEditorComponent)).componentInstance as EvidenceEditorComponent;
    evidence.viewSource(); expect(service.source).toHaveBeenCalledWith('book-a', 'chapter-a'); expect(evidence.matches).toBeTrue();
    evidence.changeChapter('chapter-b'); expect(evidence.sourceOpen).toBeFalse(); expect(evidence.source).toBe('');
  });
});
