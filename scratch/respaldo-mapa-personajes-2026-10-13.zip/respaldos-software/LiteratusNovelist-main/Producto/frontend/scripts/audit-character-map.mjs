// Synthetic local fixture only. First run backend/scripts/preview_character_map.py.
import { spawn } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const backend = resolve(root, '..', 'backend');
const output = join(root, 'docs', 'audits', 'character-map');
const profile = join(root, '.tmp-character-map-browser', `profile-${Date.now()}`);
const origin = 'http://127.0.0.1:4327';
const api = 'http://127.0.0.1:8027/api/v1/';
if (process.argv.includes('--start-servers')) {
  const fixture = spawn(join(backend, '.venv', 'Scripts', 'python.exe'), ['scripts/preview_character_map.py'],
    { cwd: backend, stdio: 'ignore', windowsHide: true });
  await new Promise((ok, fail) => {
    fixture.once('error', fail);
    fixture.once('exit', code => code === 0 ? ok() : fail(new Error(`Preview fixture failed: ${code}`)));
  });
}
const session = JSON.parse(await readFile(join(backend, '.tmp-character-map-preview', 'session.json'), 'utf8'));
const helpers = [];
const report = { checks: [], screenshots: [], runtimeErrors: [] };
await mkdir(output, { recursive: true });
await mkdir(profile, { recursive: true });
if (process.argv.includes('--start-servers')) {
  helpers.push(spawn(join(backend, '.venv', 'Scripts', 'python.exe'),
    ['manage.py', 'runserver', '127.0.0.1:8027', '--settings=config.character_map_preview_settings', '--noreload'],
    { cwd: backend, env: { ...process.env, LITERATUS_TEST_DB: join(backend, '.tmp-character-map-preview', 'preview.sqlite3'), LITERATUS_TEST_DATABASE_URL: '' }, stdio: 'ignore', windowsHide: true }));
  helpers.push(spawn(process.execPath, ['node_modules/@angular/cli/bin/ng.js', 'serve', '--configuration', 'preview', '--port', '4327', '--host', '127.0.0.1'],
    { cwd: root, stdio: 'ignore', windowsHide: true }));
}
const browser = spawn(process.env.CHROME_BIN || 'C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',
  ['--headless=new', '--disable-gpu', '--no-first-run', '--remote-debugging-port=9339', `--user-data-dir=${profile}`, 'about:blank'],
  { stdio: 'ignore', windowsHide: true });
const sleep = ms => new Promise(done => setTimeout(done, ms));
const assert = (condition, message) => { if (!condition) throw new Error(message); };
async function retry(fn, attempts = 200) {
  let failure;
  for (let i = 0; i < attempts; i++) {
    try { return await fn(); } catch (error) { failure = error; await sleep(200); }
  }
  throw failure;
}
async function apiCall(path, method = 'GET', body) {
  const response = await fetch(api + path, { method, headers: { Authorization: `Bearer ${session.access}`, 'Content-Type': 'application/json' }, ...(body ? { body: JSON.stringify(body) } : {}) });
  if (!response.ok) throw new Error(`API ${path}: ${response.status} ${(await response.text()).slice(0, 500)}`);
  return response.json();
}
const savePosition = (chapter, word) => apiCall(`library/progress/${session.progress_id}/`, 'PATCH', { current_page: chapter, current_cfi: JSON.stringify({ wordId: `word-${word}`, scrollPercent: 0, percentage: 0, timestamp: Date.now() }) });
let socket;
try {
  await retry(async () => assert((await fetch(origin, { signal: AbortSignal.timeout(1000) })).ok, 'Frontend not ready'), 400);
  await retry(async () => assert((await fetch(api + 'catalog/books/', { signal: AbortSignal.timeout(1000) })).ok, 'Backend not ready'));
  const version = await retry(async () => (await fetch('http://127.0.0.1:9339/json/version')).json());
  socket = new WebSocket(version.webSocketDebuggerUrl);
  await new Promise((ok, fail) => { socket.addEventListener('open', ok, { once: true }); socket.addEventListener('error', fail, { once: true }); });
  let sequence = 0;
  const pending = new Map();
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.method === 'Fetch.requestPaused') {
      const url = message.params.request.url.replace(/^http:\/\/(localhost|127\.0\.0\.1):8010\//, 'http://127.0.0.1:8027/');
      cmd('Fetch.continueRequest', { requestId: message.params.requestId, url }).catch(error => report.runtimeErrors.push(error.message));
      return;
    }
    if (message.method === 'Runtime.exceptionThrown') report.runtimeErrors.push(message.params.exceptionDetails.exception?.description || message.params.exceptionDetails.text);
    if (!pending.has(message.id)) return;
    const { ok, fail } = pending.get(message.id); pending.delete(message.id);
    if (message.error) fail(new Error(message.error.message)); else ok(message.result);
  });
  const send = (method, params = {}, sessionId) => new Promise((ok, fail) => {
    const id = ++sequence; pending.set(id, { ok, fail }); socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  const cmd = (method, params) => send(method, params, sessionId);
  const evaluate = async expression => {
    const result = await cmd('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
    return result.result.value;
  };
  const waitFor = expression => retry(async () => { const value = await evaluate(expression); assert(value, `Missing: ${expression}`); return value; });
  const screenshot = async name => {
    const { data } = await cmd('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
    await writeFile(join(output, name + '.png'), Buffer.from(data, 'base64'));
    report.screenshots.push(name + '.png');
  };
  await cmd('Page.enable'); await cmd('Runtime.enable');
  // Redirect only the preview build's API to our isolated server, avoiding other local previews.
  await cmd('Fetch.enable', { patterns: [{ urlPattern: 'http://localhost:8010/*' }, { urlPattern: 'http://127.0.0.1:8010/*' }] });
  await cmd('Page.addScriptToEvaluateOnNewDocument', { source: `if (location.origin === ${JSON.stringify(origin)}) {
    localStorage.setItem('access_token', ${JSON.stringify(session.access)});
    localStorage.setItem('refresh_token', ${JSON.stringify(session.refresh)});
    localStorage.setItem('user_profile', ${JSON.stringify(JSON.stringify(session.user))});
    localStorage.setItem('literatus_guide_dismissed', 'true');
    localStorage.setItem('literatus_guide_seen', 'true');
    localStorage.setItem('literatus-theme', 'neon');
  }` });
  await savePosition(1, 90);
  const earlyMap = await apiCall(`library/inventory/${session.inventory_id}/character-map/`);
  assert(earlyMap.characters.length === 5 && earlyMap.relationships.length === 5, 'Expected synthetic early cast');
  assert(!earlyMap.characters.some(character => character.role === 'antagonist'), 'Antagonist identity leaked early');
  report.checks.push('Early snapshot hides antagonist and late relationship');
  await cmd('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1080, deviceScaleFactor: 1, mobile: false });
  await cmd('Page.navigate', { url: origin + '/book-map/' + session.inventory_id });
  await waitFor("document.querySelectorAll('.character-node').length === 5");
  await sleep(800);
  for (let i = 0; i < 5; i++) {
    await evaluate("document.querySelector('[aria-label=\"Cerrar notificación\"]')?.click()");
    await sleep(100);
  }
  assert(await evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Desktop page overflow');
  await screenshot('desktop');
  await evaluate("document.documentElement.setAttribute('data-theme', 'high-contrast-dark')");
  await screenshot('high-contrast');
  await evaluate("document.documentElement.setAttribute('data-theme', 'neon')");
  await evaluate("document.querySelectorAll('.character-node')[2].click()");
  assert(await evaluate("document.querySelector('.character-detail h3').textContent.trim().length > 0"), 'Character selection failed');
  await evaluate("[...document.querySelectorAll('.view-switch button')].find(b => b.textContent.includes('Lista')).click()");
  await waitFor("document.querySelectorAll('.character-list-row').length === 5");
  report.checks.push('Diagram selection and accessible list work');
  await cmd('Emulation.setDeviceMetricsOverride', { width: 390, height: 844, deviceScaleFactor: 1, mobile: true });
  await cmd('Page.reload');
  await waitFor("document.querySelectorAll('.character-list-row').length === 5");
  assert(await evaluate('document.documentElement.scrollWidth <= innerWidth'), 'Mobile page overflow');
  await screenshot('mobile');
  report.checks.push('Mobile defaults to list without page overflow');
  await savePosition(3, 40);
  const lateMap = await apiCall(`library/inventory/${session.inventory_id}/character-map/`);
  assert(lateMap.characters.some(character => character.role === 'antagonist'), 'Late role did not reveal');
  assert(lateMap.relationships.length > earlyMap.relationships.length, 'Late relationship did not reveal');
  await savePosition(1, 90);
  const reread = await apiCall(`library/inventory/${session.inventory_id}/character-map/`);
  assert(!reread.characters.some(character => character.role === 'antagonist'), 'Reread did not hide later facts');
  report.checks.push('Late role and relationship unlock; rereading hides them again');
  await cmd('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1080, deviceScaleFactor: 1, mobile: false });
  await cmd('Page.navigate', { url: origin + '/reader/' + session.inventory_id });
  await waitFor("document.querySelector('.reading-canvas .word') && [...document.querySelectorAll('button')].some(b => b.getAttribute('aria-label') === 'Mapa de personajes')");
  await sleep(1000);
  await evaluate("[...document.querySelectorAll('button')].find(b => b.getAttribute('aria-label') === 'Mapa de personajes' && b.getBoundingClientRect().width > 0).click()");
  await waitFor("document.querySelector('.character-map-dialog') && !document.querySelector('.character-map [aria-busy=true]') && document.querySelector('.character-map [role=status], .character-map .map-toolbar')");
  await screenshot('reader-dialog');
  const colors = await evaluate("({text:getComputedStyle(document.querySelector('.graph-topline p')).color, background:getComputedStyle(document.querySelector('.map-main')).backgroundColor})");
  const luminance = color => {
    const channels = color.match(/[\d.]+/g).slice(0, 3).map(Number).map(value => value / 255).map(value => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4);
    return channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722;
  };
  const foreground = luminance(colors.text), background = luminance(colors.background);
  assert((Math.max(foreground, background) + .05) / (Math.min(foreground, background) + .05) >= 4.5, 'Reader map text contrast too low');
  assert(await evaluate("document.querySelector('.character-map-dialog').getAttribute('aria-modal') === 'true'"), 'Modal semantics absent');
  await cmd('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await cmd('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 });
  await waitFor("!document.querySelector('.character-map-dialog')");
  report.checks.push('Reader opens safe map with readable theme colors; Escape closes dialog');
  assert(report.runtimeErrors.length === 0, 'Browser runtime errors: ' + report.runtimeErrors.join('; '));
  await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
} catch (error) {
  await writeFile(join(output, 'report.json'), JSON.stringify({ ...report, failure: error.message }, null, 2));
  throw error;
} finally {
  socket?.close(); browser.kill(); helpers.forEach(helper => helper.kill());
}
